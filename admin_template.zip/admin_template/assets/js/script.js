// Add any custom JS here if needed
document.addEventListener('DOMContentLoaded', function () {
    console.log('Dashboard Loaded');
});
