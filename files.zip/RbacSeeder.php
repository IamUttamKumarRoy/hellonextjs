<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Role;
use App\Models\Permission;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class RbacSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Create Permissions grouped by module
        $this->createPermissions();

        // Create Roles
        $roles = $this->createRoles();

        // Assign Permissions to Roles
        $this->assignPermissionsToRoles($roles);

        // Create Test Users
        $this->createTestUsers($roles);
    }

    /**
     * Create permissions grouped by module
     */
    private function createPermissions(): void
    {
        $permissions = [
            // User Management
            [
                'name' => 'View Users',
                'slug' => 'users.view',
                'group' => 'Users',
                'description' => 'Can view user list and details'
            ],
            [
                'name' => 'Create Users',
                'slug' => 'users.create',
                'group' => 'Users',
                'description' => 'Can create new users'
            ],
            [
                'name' => 'Edit Users',
                'slug' => 'users.edit',
                'group' => 'Users',
                'description' => 'Can edit existing users'
            ],
            [
                'name' => 'Delete Users',
                'slug' => 'users.delete',
                'group' => 'Users',
                'description' => 'Can delete users'
            ],
            [
                'name' => 'Manage User Roles',
                'slug' => 'users.manage-roles',
                'group' => 'Users',
                'description' => 'Can assign/remove roles from users'
            ],
            [
                'name' => 'Manage User Permissions',
                'slug' => 'users.manage-permissions',
                'group' => 'Users',
                'description' => 'Can assign/remove permissions from users'
            ],

            // Role Management
            [
                'name' => 'View Roles',
                'slug' => 'roles.view',
                'group' => 'Roles',
                'description' => 'Can view roles'
            ],
            [
                'name' => 'Create Roles',
                'slug' => 'roles.create',
                'group' => 'Roles',
                'description' => 'Can create new roles'
            ],
            [
                'name' => 'Edit Roles',
                'slug' => 'roles.edit',
                'group' => 'Roles',
                'description' => 'Can edit existing roles'
            ],
            [
                'name' => 'Delete Roles',
                'slug' => 'roles.delete',
                'group' => 'Roles',
                'description' => 'Can delete roles'
            ],
            [
                'name' => 'Manage Role Permissions',
                'slug' => 'roles.manage-permissions',
                'group' => 'Roles',
                'description' => 'Can assign/remove permissions from roles'
            ],

            // Permission Management
            [
                'name' => 'View Permissions',
                'slug' => 'permissions.view',
                'group' => 'Permissions',
                'description' => 'Can view permissions'
            ],
            [
                'name' => 'Create Permissions',
                'slug' => 'permissions.create',
                'group' => 'Permissions',
                'description' => 'Can create new permissions'
            ],
            [
                'name' => 'Edit Permissions',
                'slug' => 'permissions.edit',
                'group' => 'Permissions',
                'description' => 'Can edit existing permissions'
            ],
            [
                'name' => 'Delete Permissions',
                'slug' => 'permissions.delete',
                'group' => 'Permissions',
                'description' => 'Can delete permissions'
            ],

            // Post Management
            [
                'name' => 'View Posts',
                'slug' => 'posts.view',
                'group' => 'Posts',
                'description' => 'Can view posts'
            ],
            [
                'name' => 'Create Posts',
                'slug' => 'posts.create',
                'group' => 'Posts',
                'description' => 'Can create new posts'
            ],
            [
                'name' => 'Edit Posts',
                'slug' => 'posts.edit',
                'group' => 'Posts',
                'description' => 'Can edit existing posts'
            ],
            [
                'name' => 'Delete Posts',
                'slug' => 'posts.delete',
                'group' => 'Posts',
                'description' => 'Can delete posts'
            ],
            [
                'name' => 'Publish Posts',
                'slug' => 'posts.publish',
                'group' => 'Posts',
                'description' => 'Can publish posts'
            ],

            // Category Management
            [
                'name' => 'View Categories',
                'slug' => 'categories.view',
                'group' => 'Categories',
                'description' => 'Can view categories'
            ],
            [
                'name' => 'Create Categories',
                'slug' => 'categories.create',
                'group' => 'Categories',
                'description' => 'Can create new categories'
            ],
            [
                'name' => 'Edit Categories',
                'slug' => 'categories.edit',
                'group' => 'Categories',
                'description' => 'Can edit existing categories'
            ],
            [
                'name' => 'Delete Categories',
                'slug' => 'categories.delete',
                'group' => 'Categories',
                'description' => 'Can delete categories'
            ],

            // Comment Management
            [
                'name' => 'View Comments',
                'slug' => 'comments.view',
                'group' => 'Comments',
                'description' => 'Can view comments'
            ],
            [
                'name' => 'Create Comments',
                'slug' => 'comments.create',
                'group' => 'Comments',
                'description' => 'Can create comments'
            ],
            [
                'name' => 'Edit Comments',
                'slug' => 'comments.edit',
                'group' => 'Comments',
                'description' => 'Can edit comments'
            ],
            [
                'name' => 'Delete Comments',
                'slug' => 'comments.delete',
                'group' => 'Comments',
                'description' => 'Can delete comments'
            ],
            [
                'name' => 'Moderate Comments',
                'slug' => 'comments.moderate',
                'group' => 'Comments',
                'description' => 'Can approve/reject comments'
            ],

            // Settings
            [
                'name' => 'View Settings',
                'slug' => 'settings.view',
                'group' => 'Settings',
                'description' => 'Can view application settings'
            ],
            [
                'name' => 'Edit Settings',
                'slug' => 'settings.edit',
                'group' => 'Settings',
                'description' => 'Can edit application settings'
            ],

            // Reports
            [
                'name' => 'View Reports',
                'slug' => 'reports.view',
                'group' => 'Reports',
                'description' => 'Can view reports'
            ],
            [
                'name' => 'Export Reports',
                'slug' => 'reports.export',
                'group' => 'Reports',
                'description' => 'Can export reports'
            ],
        ];

        foreach ($permissions as $permission) {
            Permission::create($permission);
        }

        $this->command->info('✅ Permissions created successfully');
    }

    /**
     * Create roles with hierarchy levels
     */
    private function createRoles(): array
    {
        $roles = [
            'super-admin' => Role::create([
                'name' => 'Super Administrator',
                'slug' => 'super-admin',
                'description' => 'Has unrestricted access to all features and settings',
                'level' => 100,
                'is_active' => true,
            ]),

            'admin' => Role::create([
                'name' => 'Administrator',
                'slug' => 'admin',
                'description' => 'Has access to most features but with some restrictions',
                'level' => 90,
                'is_active' => true,
            ]),

            'manager' => Role::create([
                'name' => 'Manager',
                'slug' => 'manager',
                'description' => 'Can manage content and users within their department',
                'level' => 70,
                'is_active' => true,
            ]),

            'editor' => Role::create([
                'name' => 'Editor',
                'slug' => 'editor',
                'description' => 'Can create, edit, and publish content',
                'level' => 50,
                'is_active' => true,
            ]),

            'author' => Role::create([
                'name' => 'Author',
                'slug' => 'author',
                'description' => 'Can create and edit their own content',
                'level' => 30,
                'is_active' => true,
            ]),

            'moderator' => Role::create([
                'name' => 'Moderator',
                'slug' => 'moderator',
                'description' => 'Can moderate comments and user-generated content',
                'level' => 40,
                'is_active' => true,
            ]),

            'user' => Role::create([
                'name' => 'User',
                'slug' => 'user',
                'description' => 'Regular user with basic access',
                'level' => 10,
                'is_active' => true,
            ]),

            'guest' => Role::create([
                'name' => 'Guest',
                'slug' => 'guest',
                'description' => 'Limited access for non-registered users',
                'level' => 1,
                'is_active' => true,
            ]),
        ];

        $this->command->info('✅ Roles created successfully');

        return $roles;
    }

    /**
     * Assign permissions to roles
     */
    private function assignPermissionsToRoles(array $roles): void
    {
        // Super Admin - All Permissions
        $roles['super-admin']->syncPermissions(Permission::all()->pluck('slug')->toArray());

        // Admin - Most Permissions (except some critical ones)
        $adminPermissions = Permission::whereNotIn('slug', [
            'permissions.delete',
            'roles.delete',
        ])->pluck('slug')->toArray();
        $roles['admin']->syncPermissions($adminPermissions);

        // Manager - User and Content Management
        $roles['manager']->syncPermissions([
            'users.view', 'users.create', 'users.edit', 'users.manage-roles',
            'posts.view', 'posts.create', 'posts.edit', 'posts.delete', 'posts.publish',
            'categories.view', 'categories.create', 'categories.edit',
            'comments.view', 'comments.moderate', 'comments.delete',
            'reports.view', 'reports.export',
        ]);

        // Editor - Full Content Management
        $roles['editor']->syncPermissions([
            'posts.view', 'posts.create', 'posts.edit', 'posts.delete', 'posts.publish',
            'categories.view', 'categories.create', 'categories.edit',
            'comments.view', 'comments.edit', 'comments.delete', 'comments.moderate',
        ]);

        // Author - Own Content Management
        $roles['author']->syncPermissions([
            'posts.view', 'posts.create', 'posts.edit',
            'categories.view',
            'comments.view', 'comments.create',
        ]);

        // Moderator - Comment Moderation
        $roles['moderator']->syncPermissions([
            'posts.view',
            'comments.view', 'comments.edit', 'comments.delete', 'comments.moderate',
        ]);

        // User - Basic Access
        $roles['user']->syncPermissions([
            'posts.view',
            'categories.view',
            'comments.view', 'comments.create',
        ]);

        // Guest - Read Only
        $roles['guest']->syncPermissions([
            'posts.view',
            'categories.view',
        ]);

        $this->command->info('✅ Permissions assigned to roles successfully');
    }

    /**
     * Create test users with different roles
     */
    private function createTestUsers(array $roles): void
    {
        // Super Admin User
        $superAdmin = User::create([
            'name' => 'Super Admin',
            'email' => 'superadmin@example.com',
            'password' => Hash::make('password'),
            'email_verified_at' => now(),
        ]);
        $superAdmin->assignRole('super-admin');

        // Admin User
        $admin = User::create([
            'name' => 'Admin User',
            'email' => 'admin@example.com',
            'password' => Hash::make('password'),
            'email_verified_at' => now(),
        ]);
        $admin->assignRole('admin');

        // Manager User
        $manager = User::create([
            'name' => 'Manager User',
            'email' => 'manager@example.com',
            'password' => Hash::make('password'),
            'email_verified_at' => now(),
        ]);
        $manager->assignRole('manager');

        // Editor User
        $editor = User::create([
            'name' => 'Editor User',
            'email' => 'editor@example.com',
            'password' => Hash::make('password'),
            'email_verified_at' => now(),
        ]);
        $editor->assignRole('editor');

        // Author User
        $author = User::create([
            'name' => 'Author User',
            'email' => 'author@example.com',
            'password' => Hash::make('password'),
            'email_verified_at' => now(),
        ]);
        $author->assignRole('author');

        // Moderator User
        $moderator = User::create([
            'name' => 'Moderator User',
            'email' => 'moderator@example.com',
            'password' => Hash::make('password'),
            'email_verified_at' => now(),
        ]);
        $moderator->assignRole('moderator');

        // Regular User
        $user = User::create([
            'name' => 'Regular User',
            'email' => 'user@example.com',
            'password' => Hash::make('password'),
            'email_verified_at' => now(),
        ]);
        $user->assignRole('user');

        // User with Multiple Roles
        $multiRole = User::create([
            'name' => 'Multi Role User',
            'email' => 'multirole@example.com',
            'password' => Hash::make('password'),
            'email_verified_at' => now(),
        ]);
        $multiRole->assignRole(['editor', 'moderator']);

        // User with Direct Permission
        $directPerm = User::create([
            'name' => 'Direct Permission User',
            'email' => 'directperm@example.com',
            'password' => Hash::make('password'),
            'email_verified_at' => now(),
        ]);
        $directPerm->assignRole('user');
        $directPerm->givePermissionTo(['posts.create', 'posts.edit']);

        $this->command->info('✅ Test users created successfully');
        $this->command->info('');
        $this->command->info('📧 Login Credentials (password: password):');
        $this->command->info('   Super Admin: superadmin@example.com');
        $this->command->info('   Admin: admin@example.com');
        $this->command->info('   Manager: manager@example.com');
        $this->command->info('   Editor: editor@example.com');
        $this->command->info('   Author: author@example.com');
        $this->command->info('   Moderator: moderator@example.com');
        $this->command->info('   User: user@example.com');
    }
}
