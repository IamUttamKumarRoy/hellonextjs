<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('permission_user', function (Blueprint $table) {
            $table->id();
            $table->foreignId('permission_id')->constrained()->onDelete('cascade');
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->timestamp('assigned_at')->useCurrent();
            $table->foreignId('assigned_by')->nullable()->constrained('users')->onDelete('set null');
            $table->timestamp('expires_at')->nullable(); // For temporary permission assignments
            $table->boolean('is_forbidden')->default(false); // To explicitly forbid a permission
            $table->timestamps();

            // Composite unique index to prevent duplicate assignments
            $table->unique(['permission_id', 'user_id']);
            
            // Indexes for performance
            $table->index('user_id');
            $table->index('permission_id');
            $table->index('expires_at');
            $table->index('is_forbidden');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('permission_user');
    }
};
