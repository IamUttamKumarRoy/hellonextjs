# Laravel RBAC System - Complete Implementation Guide

A comprehensive Role-Based Access Control (RBAC) system for Laravel with users, roles, permissions, and all pivot tables.

## 📋 Table of Contents
- [Database Structure](#database-structure)
- [Installation](#installation)
- [Models](#models)
- [Usage Examples](#usage-examples)
- [Middleware](#middleware)
- [Blade Directives](#blade-directives)
- [Advanced Features](#advanced-features)
- [API Reference](#api-reference)

---

## 🗄️ Database Structure

### Tables Overview
```
users
├── id
├── name
├── email
├── password
└── timestamps

roles
├── id
├── name (unique)
├── slug (unique)
├── description
├── level (for hierarchy)
├── is_active
├── timestamps
└── soft_deletes

permissions
├── id
├── name (unique)
├── slug (unique)
├── group (for grouping)
├── description
├── is_active
├── timestamps
└── soft_deletes

role_user (Pivot)
├── id
├── role_id (FK)
├── user_id (FK)
├── assigned_at
├── assigned_by (FK to users)
├── expires_at (for temporary roles)
└── timestamps

permission_role (Pivot)
├── id
├── permission_id (FK)
├── role_id (FK)
├── assigned_at
├── assigned_by (FK to users)
└── timestamps

permission_user (Pivot)
├── id
├── permission_id (FK)
├── user_id (FK)
├── assigned_at
├── assigned_by (FK to users)
├── expires_at (for temporary permissions)
├── is_forbidden (to explicitly deny permissions)
└── timestamps
```

### Relationships
```
User
├── belongsToMany(Role) through role_user
└── belongsToMany(Permission) through permission_user

Role
├── belongsToMany(User) through role_user
└── belongsToMany(Permission) through permission_role

Permission
├── belongsToMany(Role) through permission_role
└── belongsToMany(User) through permission_user
```

---

## 🚀 Installation

### Step 1: Run Migrations
```bash
php artisan migrate
```

### Step 2: Run Seeder
```bash
php artisan db:seed --class=RbacSeeder
```

This will create:
- 32 permissions grouped by module
- 8 roles with hierarchy
- 9 test users with different permissions

### Step 3: Register Middleware

**File: `bootstrap/app.php`**
```php
use App\Http\Middleware\RoleMiddleware;
use App\Http\Middleware\PermissionMiddleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withMiddleware(function (Middleware $middleware) {
        $middleware->alias([
            'role' => RoleMiddleware::class,
            'permission' => PermissionMiddleware::class,
        ]);
    })
    ->create();
```

### Step 4: Create Middleware Files

**File: `app/Http/Middleware/RoleMiddleware.php`**
```php
<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class RoleMiddleware
{
    public function handle(Request $request, Closure $next, string ...$roles)
    {
        if (!$request->user()) {
            abort(401, 'Unauthorized');
        }

        if (!$request->user()->hasAnyRole($roles)) {
            abort(403, 'Forbidden - Insufficient role permissions');
        }

        return $next($request);
    }
}
```

**File: `app/Http/Middleware/PermissionMiddleware.php`**
```php
<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class PermissionMiddleware
{
    public function handle(Request $request, Closure $next, string ...$permissions)
    {
        if (!$request->user()) {
            abort(401, 'Unauthorized');
        }

        if (!$request->user()->hasAnyPermission($permissions)) {
            abort(403, 'Forbidden - Insufficient permissions');
        }

        return $next($request);
    }
}
```

### Step 5: Register Service Provider (Optional - for Blade Directives)

**Create: `app/Providers/RbacServiceProvider.php`**
```php
<?php

namespace App\Providers;

use Illuminate\Support\Facades\Blade;
use Illuminate\Support\ServiceProvider;

class RbacServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        Blade::if('role', function (string $role) {
            return auth()->check() && auth()->user()->hasRole($role);
        });

        Blade::if('anyrole', function (array $roles) {
            return auth()->check() && auth()->user()->hasAnyRole($roles);
        });

        Blade::if('permission', function (string $permission) {
            return auth()->check() && auth()->user()->hasPermission($permission);
        });

        Blade::if('anypermission', function (array $permissions) {
            return auth()->check() && auth()->user()->hasAnyPermission($permissions);
        });
    }
}
```

**Register in `bootstrap/providers.php`:**
```php
return [
    App\Providers\AppServiceProvider::class,
    App\Providers\RbacServiceProvider::class,
];
```

---

## 📚 Usage Examples

### 1. Role Management

#### Assign Role to User
```php
$user = User::find(1);

// Single role
$user->assignRole('admin');

// Multiple roles
$user->assignRole(['admin', 'editor']);

// With Role model
$adminRole = Role::where('slug', 'admin')->first();
$user->assignRole($adminRole);

// With expiration
$user->assignRole('editor', ['expires_at' => now()->addDays(30)]);
```

#### Remove Role from User
```php
// Remove single role
$user->removeRole('editor');

// Remove multiple roles
$user->removeRole(['editor', 'moderator']);
```

#### Sync Roles (Replace all roles)
```php
// Remove all existing roles and assign new ones
$user->syncRoles(['admin', 'manager']);
```

#### Check User Roles
```php
// Check single role
if ($user->hasRole('admin')) {
    // User is admin
}

// Check any role
if ($user->hasAnyRole(['admin', 'editor'])) {
    // User is admin OR editor
}

// Check all roles
if ($user->hasAllRoles(['admin', 'verified'])) {
    // User has both roles
}

// Get all roles
$roles = $user->getActiveRoles();
$roleSlugs = $user->getRoleSlugs();
```

### 2. Permission Management

#### Give Permission to User (Direct)
```php
$user = User::find(1);

// Single permission
$user->givePermissionTo('posts.create');

// Multiple permissions
$user->givePermissionTo(['posts.create', 'posts.edit']);

// With Permission model
$permission = Permission::where('slug', 'posts.publish')->first();
$user->givePermissionTo($permission);

// With expiration
$user->givePermissionTo('posts.publish', ['expires_at' => now()->addDays(7)]);
```

#### Revoke Permission from User
```php
$user->revokePermissionTo('posts.create');
$user->revokePermissionTo(['posts.create', 'posts.edit']);
```

#### Forbid Permission (Explicit Denial)
```php
// This will deny the permission even if user has it through a role
$user->forbidPermission('users.delete');

// Remove the forbid
$user->unforbidPermission('users.delete');

// Check if forbidden
if ($user->isPermissionForbidden('users.delete')) {
    // Permission is explicitly denied
}
```

#### Check User Permissions
```php
// Check single permission
if ($user->hasPermission('posts.create')) {
    // User can create posts
}

// Check any permission
if ($user->hasAnyPermission(['posts.edit', 'posts.delete'])) {
    // User can edit OR delete posts
}

// Check all permissions
if ($user->hasAllPermissions(['posts.create', 'posts.edit'])) {
    // User can both create AND edit posts
}

// Get all permissions
$permissions = $user->getAllPermissions();
$permissionSlugs = $user->getPermissionSlugs();
```

### 3. Role Permission Management

#### Assign Permission to Role
```php
$role = Role::where('slug', 'editor')->first();

// Single permission
$role->givePermissionTo('posts.publish');

// Multiple permissions
$role->givePermissionTo(['posts.create', 'posts.edit', 'posts.delete']);

// With Permission model
$permission = Permission::where('slug', 'posts.publish')->first();
$role->givePermissionTo($permission);
```

#### Remove Permission from Role
```php
$role->revokePermissionTo('posts.delete');
$role->revokePermissionTo(['posts.edit', 'posts.delete']);
```

#### Sync Permissions for Role
```php
// Replace all permissions with new ones
$role->syncPermissions([
    'posts.view',
    'posts.create',
    'posts.edit'
]);
```

#### Check Role Permissions
```php
if ($role->hasPermission('posts.create')) {
    // Role has this permission
}

if ($role->hasAnyPermission(['posts.edit', 'posts.delete'])) {
    // Role has any of these permissions
}

if ($role->hasAllPermissions(['posts.create', 'posts.edit'])) {
    // Role has all these permissions
}
```

### 4. Route Protection

**File: `routes/web.php`**

```php
use Illuminate\Support\Facades\Route;

// Protect by single role
Route::middleware(['auth', 'role:admin'])->group(function () {
    Route::get('/admin/dashboard', [AdminController::class, 'dashboard']);
});

// Protect by multiple roles (user must have ANY of these)
Route::middleware(['auth', 'role:admin,manager'])->group(function () {
    Route::resource('users', UserController::class);
});

// Protect by permission
Route::middleware(['auth', 'permission:posts.create'])->group(function () {
    Route::get('/posts/create', [PostController::class, 'create']);
    Route::post('/posts', [PostController::class, 'store']);
});

// Protect by multiple permissions (user must have ANY of these)
Route::middleware(['auth', 'permission:posts.edit,posts.delete'])->group(function () {
    Route::put('/posts/{post}', [PostController::class, 'update']);
    Route::delete('/posts/{post}', [PostController::class, 'destroy']);
});

// Combine role and permission
Route::middleware(['auth', 'role:admin', 'permission:users.delete'])->group(function () {
    Route::delete('/users/{user}', [UserController::class, 'destroy']);
});
```

### 5. Controller Usage

```php
<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;

class PostController extends Controller
{
    public function index()
    {
        // Check permission in method
        if (!auth()->user()->hasPermission('posts.view')) {
            abort(403, 'Unauthorized to view posts');
        }

        $posts = Post::all();
        return view('posts.index', compact('posts'));
    }

    public function create()
    {
        // Alternative check
        abort_unless(auth()->user()->hasPermission('posts.create'), 403);

        return view('posts.create');
    }

    public function store(Request $request)
    {
        // Check in conditional
        if (auth()->user()->hasPermission('posts.publish')) {
            // Directly publish
            $post = Post::create([
                'title' => $request->title,
                'content' => $request->content,
                'status' => 'published',
            ]);
        } else {
            // Save as draft
            $post = Post::create([
                'title' => $request->title,
                'content' => $request->content,
                'status' => 'draft',
            ]);
        }

        return redirect()->route('posts.show', $post);
    }

    public function destroy(Post $post)
    {
        $user = auth()->user();

        // Check multiple conditions
        if (!$user->hasPermission('posts.delete') && $post->user_id !== $user->id) {
            abort(403, 'Unauthorized to delete this post');
        }

        $post->delete();
        return redirect()->route('posts.index');
    }
}
```

### 6. Blade Directives

```blade
{{-- Check single role --}}
@role('admin')
    <div class="admin-panel">
        <h2>Admin Controls</h2>
    </div>
@endrole

{{-- Check multiple roles --}}
@anyrole(['admin', 'editor'])
    <a href="{{ route('posts.create') }}">Create Post</a>
@endanyrole

{{-- Check permission --}}
@permission('posts.publish')
    <button class="btn-publish">Publish</button>
@endpermission

{{-- Check multiple permissions --}}
@anypermission(['posts.edit', 'posts.delete'])
    <div class="post-actions">
        @permission('posts.edit')
            <a href="{{ route('posts.edit', $post) }}">Edit</a>
        @endpermission
        
        @permission('posts.delete')
            <form action="{{ route('posts.destroy', $post) }}" method="POST">
                @csrf
                @method('DELETE')
                <button type="submit">Delete</button>
            </form>
        @endpermission
    </div>
@endanypermission

{{-- With else --}}
@role('admin')
    <p>Welcome, Administrator!</p>
@else
    <p>You don't have admin access</p>
@endrole
```

### 7. Query Scopes

```php
// Get all users with 'admin' role
$admins = User::withRole('admin')->get();

// Get users with multiple roles
$editors = User::withRole(['editor', 'author'])->get();

// Get users with a specific permission
$publishers = User::withPermission('posts.publish')->get();

// Get active roles
$activeRoles = Role::active()->get();

// Get roles above level 50
$seniorRoles = Role::aboveLevel(50)->get();

// Get permissions by group
$postPermissions = Permission::byGroup('Posts')->get();

// Get permissions in multiple groups
$contentPermissions = Permission::inGroups(['Posts', 'Categories'])->get();
```

### 8. Advanced Examples

#### Temporary Roles
```php
// Assign role that expires in 30 days
$user->assignRole('premium', ['expires_at' => now()->addDays(30)]);

// Check if role is still valid (automatically handled by hasRole)
if ($user->hasRole('premium')) {
    // User has active premium role
}
```

#### Temporary Permissions
```php
// Give temporary permission for 7 days
$user->givePermissionTo('posts.publish', ['expires_at' => now()->addDays(7)]);
```

#### Role Hierarchy
```php
$adminRole = Role::where('slug', 'admin')->first();
$userRole = Role::where('slug', 'user')->first();

// Check hierarchy
if ($adminRole->hasHigherLevelThan($userRole)) {
    // Admin has higher level
}

// Get roles above certain level
$seniorRoles = Role::aboveLevel(50)->get();
```

#### Permission Groups
```php
// Get all permission groups
$groups = Permission::getAllGroups();

// Get permissions by group
$userPermissions = Permission::byGroup('Users')->get();

foreach ($groups as $group) {
    echo "Group: {$group}\n";
    $permissions = Permission::byGroup($group)->get();
    foreach ($permissions as $permission) {
        echo "  - {$permission->name}\n";
    }
}
```

#### Bulk Operations
```php
// Assign multiple roles to multiple users
$users = User::whereIn('id', [1, 2, 3])->get();
foreach ($users as $user) {
    $user->assignRole(['editor', 'moderator']);
}

// Give permission to all users with a role
$editors = User::withRole('editor')->get();
foreach ($editors as $editor) {
    $editor->givePermissionTo('posts.publish');
}
```

#### Cache Management
```php
// Flush permission cache for user (automatically done on role/permission changes)
$user->flushPermissionCache();

// Get cached permissions
$permissions = $user->getAllPermissions(); // Cached for 1 hour
```

---

## 🔐 Middleware Reference

### Role Middleware
```php
// Single role
Route::middleware('role:admin')->group(function () {
    //
});

// Multiple roles (user needs ANY)
Route::middleware('role:admin,manager')->group(function () {
    //
});
```

### Permission Middleware
```php
// Single permission
Route::middleware('permission:posts.create')->group(function () {
    //
});

// Multiple permissions (user needs ANY)
Route::middleware('permission:posts.edit,posts.delete')->group(function () {
    //
});
```

---

## 🎨 Blade Directives Reference

| Directive | Description | Example |
|-----------|-------------|---------|
| `@role('name')` | Check single role | `@role('admin')` |
| `@anyrole(['r1', 'r2'])` | Check any role | `@anyrole(['admin', 'editor'])` |
| `@permission('slug')` | Check single permission | `@permission('posts.create')` |
| `@anypermission(['p1', 'p2'])` | Check any permission | `@anypermission(['posts.edit', 'posts.delete'])` |

---

## 📊 Testing

### Feature Test Example

```php
<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use App\Models\Role;
use App\Models\Permission;
use Illuminate\Foundation\Testing\RefreshDatabase;

class RbacTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(RbacSeeder::class);
    }

    public function test_user_can_be_assigned_role()
    {
        $user = User::factory()->create();
        $user->assignRole('admin');

        $this->assertTrue($user->hasRole('admin'));
    }

    public function test_user_has_permission_through_role()
    {
        $user = User::factory()->create();
        $user->assignRole('editor');

        $this->assertTrue($user->hasPermission('posts.create'));
        $this->assertTrue($user->hasPermission('posts.edit'));
        $this->assertFalse($user->hasPermission('users.delete'));
    }

    public function test_user_can_have_direct_permission()
    {
        $user = User::factory()->create();
        $user->assignRole('user');
        $user->givePermissionTo('posts.create');

        $this->assertTrue($user->hasPermission('posts.create'));
    }

    public function test_forbidden_permission_overrides_role()
    {
        $user = User::factory()->create();
        $user->assignRole('editor');
        $user->forbidPermission('posts.delete');

        $this->assertFalse($user->hasPermission('posts.delete'));
    }

    public function test_middleware_blocks_unauthorized_user()
    {
        $user = User::factory()->create();
        $user->assignRole('user');

        $response = $this->actingAs($user)->get('/admin/dashboard');
        $response->assertStatus(403);
    }

    public function test_middleware_allows_authorized_user()
    {
        $user = User::factory()->create();
        $user->assignRole('admin');

        $response = $this->actingAs($user)->get('/admin/dashboard');
        $response->assertStatus(200);
    }

    public function test_temporary_role_expires()
    {
        $user = User::factory()->create();
        $user->assignRole('premium', ['expires_at' => now()->subDay()]);

        $this->assertFalse($user->hasRole('premium'));
    }
}
```

---

## 🎯 Best Practices

1. **Use Role Slugs**: Always use slugs for checking roles and permissions
2. **Cache Permissions**: Permissions are automatically cached for 1 hour
3. **Role Hierarchy**: Use the `level` field to implement role hierarchy
4. **Permission Groups**: Group related permissions for better organization
5. **Forbidden Permissions**: Use sparingly, only when you need explicit denial
6. **Temporary Access**: Use expiration dates for trial periods or temporary access
7. **Middleware**: Always protect routes with middleware rather than controller checks
8. **Testing**: Write tests for your RBAC logic

---

## 📝 Summary

This RBAC system provides:

✅ **Complete Database Structure**: 6 tables with proper relationships
✅ **Flexible Permission System**: Role-based and direct permissions
✅ **Advanced Features**: Temporary access, forbidden permissions, role hierarchy
✅ **Easy Integration**: Middleware, Blade directives, query scopes
✅ **Performance**: Built-in caching for permissions
✅ **Well Documented**: Comprehensive examples and use cases

All files are ready to use. Just copy them to your Laravel project and run the migrations and seeder!
