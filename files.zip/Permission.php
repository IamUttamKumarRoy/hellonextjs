<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class Permission extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'name',
        'slug',
        'group',
        'description',
        'is_active',
    ];

    protected $casts = [
        'is_active' => 'boolean',
    ];

    /**
     * Boot method for model events
     */
    protected static function boot()
    {
        parent::boot();

        // Automatically generate slug from name
        static::creating(function ($permission) {
            if (empty($permission->slug)) {
                $permission->slug = Str::slug($permission->name);
            }
        });
    }

    /**
     * A permission belongs to many roles
     */
    public function roles(): BelongsToMany
    {
        return $this->belongsToMany(Role::class, 'permission_role')
            ->withPivot('assigned_at', 'assigned_by')
            ->withTimestamps();
    }

    /**
     * A permission belongs to many users (direct permissions)
     */
    public function users(): BelongsToMany
    {
        return $this->belongsToMany(User::class, 'permission_user')
            ->withPivot('assigned_at', 'assigned_by', 'expires_at', 'is_forbidden')
            ->withTimestamps();
    }

    /**
     * Assign this permission to a role
     */
    public function assignToRole(string|Role $role): self
    {
        if (is_string($role)) {
            $role = Role::where('slug', $role)->firstOrFail();
        }

        $this->roles()->syncWithoutDetaching($role);

        return $this;
    }

    /**
     * Remove this permission from a role
     */
    public function removeFromRole(string|Role $role): self
    {
        if (is_string($role)) {
            $role = Role::where('slug', $role)->firstOrFail();
        }

        $this->roles()->detach($role);

        return $this;
    }

    /**
     * Assign this permission to a user
     */
    public function assignToUser(User $user, array $attributes = []): self
    {
        $this->users()->syncWithoutDetaching([$user->id => $attributes]);

        return $this;
    }

    /**
     * Remove this permission from a user
     */
    public function removeFromUser(User $user): self
    {
        $this->users()->detach($user);

        return $this;
    }

    /**
     * Get all users who have this permission (via role or direct)
     */
    public function getAllUsers()
    {
        // Users with direct permission
        $directUsers = $this->users()->pluck('users.id');

        // Users with permission via roles
        $roleUserIds = User::whereHas('roles', function ($query) {
            $query->whereHas('permissions', function ($q) {
                $q->where('permissions.id', $this->id);
            });
        })->pluck('id');

        return User::whereIn('id', $directUsers->merge($roleUserIds)->unique())->get();
    }

    /**
     * Scope to get only active permissions
     */
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    /**
     * Scope to get permissions by group
     */
    public function scopeByGroup($query, string $group)
    {
        return $query->where('group', $group);
    }

    /**
     * Scope to get permissions by multiple groups
     */
    public function scopeInGroups($query, array $groups)
    {
        return $query->whereIn('group', $groups);
    }

    /**
     * Get all unique groups
     */
    public static function getAllGroups(): array
    {
        return static::whereNotNull('group')
            ->distinct()
            ->pluck('group')
            ->toArray();
    }

    /**
     * Get the route key for the model
     */
    public function getRouteKeyName(): string
    {
        return 'slug';
    }
}
