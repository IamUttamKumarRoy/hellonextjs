<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Collection;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

    protected $fillable = [
        'name',
        'email',
        'password',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }

    /**
     * A user has many roles
     */
    public function roles(): BelongsToMany
    {
        return $this->belongsToMany(Role::class, 'role_user')
            ->withPivot('assigned_at', 'assigned_by', 'expires_at')
            ->withTimestamps();
    }

    /**
     * A user has many direct permissions
     */
    public function permissions(): BelongsToMany
    {
        return $this->belongsToMany(Permission::class, 'permission_user')
            ->withPivot('assigned_at', 'assigned_by', 'expires_at', 'is_forbidden')
            ->withTimestamps();
    }

    // ==================== ROLE METHODS ====================

    /**
     * Assign a role to the user
     */
    public function assignRole(string|Role|array $roles, array $attributes = []): self
    {
        $roles = $this->normalizeRoles($roles);
        
        $roleIds = Role::whereIn('slug', $roles)->pluck('id');
        
        foreach ($roleIds as $roleId) {
            $this->roles()->syncWithoutDetaching([
                $roleId => array_merge([
                    'assigned_at' => now(),
                    'assigned_by' => auth()->id(),
                ], $attributes)
            ]);
        }

        $this->flushPermissionCache();

        return $this;
    }

    /**
     * Remove a role from the user
     */
    public function removeRole(string|Role|array $roles): self
    {
        $roles = $this->normalizeRoles($roles);
        
        $roleIds = Role::whereIn('slug', $roles)->pluck('id');
        
        $this->roles()->detach($roleIds);

        $this->flushPermissionCache();

        return $this;
    }

    /**
     * Sync roles (remove all existing and assign new ones)
     */
    public function syncRoles(array $roles): self
    {
        $roles = $this->normalizeRoles($roles);
        
        $roleIds = Role::whereIn('slug', $roles)->pluck('id');
        
        $syncData = [];
        foreach ($roleIds as $roleId) {
            $syncData[$roleId] = [
                'assigned_at' => now(),
                'assigned_by' => auth()->id(),
            ];
        }
        
        $this->roles()->sync($syncData);

        $this->flushPermissionCache();

        return $this;
    }

    /**
     * Check if user has a specific role
     */
    public function hasRole(string|Role|array $role): bool
    {
        if (is_array($role)) {
            return $this->hasAnyRole($role);
        }

        if ($role instanceof Role) {
            $role = $role->slug;
        }

        return $this->roles()
            ->where('roles.slug', $role)
            ->where('roles.is_active', true)
            ->where(function ($query) {
                $query->whereNull('role_user.expires_at')
                      ->orWhere('role_user.expires_at', '>', now());
            })
            ->exists();
    }

    /**
     * Check if user has any of the given roles
     */
    public function hasAnyRole(array $roles): bool
    {
        $roles = $this->normalizeRoles($roles);

        return $this->roles()
            ->whereIn('roles.slug', $roles)
            ->where('roles.is_active', true)
            ->where(function ($query) {
                $query->whereNull('role_user.expires_at')
                      ->orWhere('role_user.expires_at', '>', now());
            })
            ->exists();
    }

    /**
     * Check if user has all of the given roles
     */
    public function hasAllRoles(array $roles): bool
    {
        $roles = $this->normalizeRoles($roles);

        $count = $this->roles()
            ->whereIn('roles.slug', $roles)
            ->where('roles.is_active', true)
            ->where(function ($query) {
                $query->whereNull('role_user.expires_at')
                      ->orWhere('role_user.expires_at', '>', now());
            })
            ->count();

        return $count === count($roles);
    }

    /**
     * Get all active roles for the user
     */
    public function getActiveRoles(): Collection
    {
        return $this->roles()
            ->where('roles.is_active', true)
            ->where(function ($query) {
                $query->whereNull('role_user.expires_at')
                      ->orWhere('role_user.expires_at', '>', now());
            })
            ->get();
    }

    /**
     * Get all role slugs for the user
     */
    public function getRoleSlugs(): array
    {
        return $this->getActiveRoles()->pluck('slug')->toArray();
    }

    // ==================== PERMISSION METHODS ====================

    /**
     * Give direct permission to user
     */
    public function givePermissionTo(string|Permission|array $permissions, array $attributes = []): self
    {
        $permissions = $this->normalizePermissions($permissions);
        
        $permissionIds = Permission::whereIn('slug', $permissions)->pluck('id');
        
        foreach ($permissionIds as $permissionId) {
            $this->permissions()->syncWithoutDetaching([
                $permissionId => array_merge([
                    'assigned_at' => now(),
                    'assigned_by' => auth()->id(),
                    'is_forbidden' => false,
                ], $attributes)
            ]);
        }

        $this->flushPermissionCache();

        return $this;
    }

    /**
     * Revoke direct permission from user
     */
    public function revokePermissionTo(string|Permission|array $permissions): self
    {
        $permissions = $this->normalizePermissions($permissions);
        
        $permissionIds = Permission::whereIn('slug', $permissions)->pluck('id');
        
        $this->permissions()->detach($permissionIds);

        $this->flushPermissionCache();

        return $this;
    }

    /**
     * Forbid a permission (explicit denial, overrides role permissions)
     */
    public function forbidPermission(string|Permission|array $permissions): self
    {
        $permissions = $this->normalizePermissions($permissions);
        
        $permissionIds = Permission::whereIn('slug', $permissions)->pluck('id');
        
        foreach ($permissionIds as $permissionId) {
            $this->permissions()->syncWithoutDetaching([
                $permissionId => [
                    'assigned_at' => now(),
                    'assigned_by' => auth()->id(),
                    'is_forbidden' => true,
                ]
            ]);
        }

        $this->flushPermissionCache();

        return $this;
    }

    /**
     * Unforbid a permission
     */
    public function unforbidPermission(string|Permission|array $permissions): self
    {
        return $this->revokePermissionTo($permissions);
    }

    /**
     * Check if a permission is explicitly forbidden
     */
    public function isPermissionForbidden(string|Permission $permission): bool
    {
        if ($permission instanceof Permission) {
            $permission = $permission->slug;
        }

        return $this->permissions()
            ->where('permissions.slug', $permission)
            ->wherePivot('is_forbidden', true)
            ->exists();
    }

    /**
     * Check if user has a specific permission (via role or direct)
     */
    public function hasPermission(string|Permission|array $permission): bool
    {
        if (is_array($permission)) {
            return $this->hasAnyPermission($permission);
        }

        if ($permission instanceof Permission) {
            $permission = $permission->slug;
        }

        // Check if permission is explicitly forbidden
        if ($this->isPermissionForbidden($permission)) {
            return false;
        }

        // Check direct permissions (not forbidden and not expired)
        $hasDirectPermission = $this->permissions()
            ->where('permissions.slug', $permission)
            ->where('permissions.is_active', true)
            ->wherePivot('is_forbidden', false)
            ->where(function ($query) {
                $query->whereNull('permission_user.expires_at')
                      ->orWhere('permission_user.expires_at', '>', now());
            })
            ->exists();

        if ($hasDirectPermission) {
            return true;
        }

        // Check permissions via roles
        return $this->roles()
            ->where('roles.is_active', true)
            ->where(function ($query) {
                $query->whereNull('role_user.expires_at')
                      ->orWhere('role_user.expires_at', '>', now());
            })
            ->whereHas('permissions', function ($query) use ($permission) {
                $query->where('permissions.slug', $permission)
                      ->where('permissions.is_active', true);
            })
            ->exists();
    }

    /**
     * Check if user has any of the given permissions
     */
    public function hasAnyPermission(array $permissions): bool
    {
        foreach ($permissions as $permission) {
            if ($this->hasPermission($permission)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Check if user has all of the given permissions
     */
    public function hasAllPermissions(array $permissions): bool
    {
        foreach ($permissions as $permission) {
            if (!$this->hasPermission($permission)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Get all permissions for the user (from roles and direct)
     */
    public function getAllPermissions(): Collection
    {
        return cache()->remember(
            "user.{$this->id}.permissions",
            now()->addHours(1),
            function () {
                // Get direct permissions (not forbidden and not expired)
                $directPermissions = $this->permissions()
                    ->where('permissions.is_active', true)
                    ->wherePivot('is_forbidden', false)
                    ->where(function ($query) {
                        $query->whereNull('permission_user.expires_at')
                              ->orWhere('permission_user.expires_at', '>', now());
                    })
                    ->get();

                // Get permissions from active roles
                $rolePermissions = Permission::active()
                    ->whereHas('roles', function ($query) {
                        $query->whereIn('roles.id', $this->getActiveRoles()->pluck('id'));
                    })
                    ->get();

                // Get forbidden permissions
                $forbiddenPermissionIds = $this->permissions()
                    ->wherePivot('is_forbidden', true)
                    ->pluck('permissions.id');

                // Merge and remove forbidden permissions
                return $directPermissions
                    ->merge($rolePermissions)
                    ->unique('id')
                    ->reject(function ($permission) use ($forbiddenPermissionIds) {
                        return $forbiddenPermissionIds->contains($permission->id);
                    });
            }
        );
    }

    /**
     * Get all permission slugs for the user
     */
    public function getPermissionSlugs(): array
    {
        return $this->getAllPermissions()->pluck('slug')->toArray();
    }

    /**
     * Check if user is a super admin (has all permissions)
     */
    public function isSuperAdmin(): bool
    {
        return $this->hasRole('super-admin') || $this->hasRole('administrator');
    }

    /**
     * Flush permission cache for this user
     */
    public function flushPermissionCache(): void
    {
        cache()->forget("user.{$this->id}.permissions");
    }

    // ==================== HELPER METHODS ====================

    /**
     * Normalize roles to array of slugs
     */
    protected function normalizeRoles(string|Role|array $roles): array
    {
        if (!is_array($roles)) {
            $roles = [$roles];
        }

        return collect($roles)->map(function ($role) {
            if ($role instanceof Role) {
                return $role->slug;
            }
            return $role;
        })->toArray();
    }

    /**
     * Normalize permissions to array of slugs
     */
    protected function normalizePermissions(string|Permission|array $permissions): array
    {
        if (!is_array($permissions)) {
            $permissions = [$permissions];
        }

        return collect($permissions)->map(function ($permission) {
            if ($permission instanceof Permission) {
                return $permission->slug;
            }
            return $permission;
        })->toArray();
    }

    /**
     * Scope to get users with a specific role
     */
    public function scopeWithRole($query, string|array $role)
    {
        if (!is_array($role)) {
            $role = [$role];
        }

        return $query->whereHas('roles', function ($q) use ($role) {
            $q->whereIn('slug', $role);
        });
    }

    /**
     * Scope to get users with a specific permission
     */
    public function scopeWithPermission($query, string $permission)
    {
        return $query->where(function ($q) use ($permission) {
            // Has direct permission
            $q->whereHas('permissions', function ($query) use ($permission) {
                $query->where('slug', $permission)
                      ->where('is_forbidden', false);
            })
            // Or has permission via role
            ->orWhereHas('roles.permissions', function ($query) use ($permission) {
                $query->where('slug', $permission);
            });
        });
    }
}
