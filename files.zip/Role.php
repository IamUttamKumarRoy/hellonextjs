<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class Role extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'name',
        'slug',
        'description',
        'level',
        'is_active',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'level' => 'integer',
    ];

    /**
     * Boot method for model events
     */
    protected static function boot()
    {
        parent::boot();

        // Automatically generate slug from name
        static::creating(function ($role) {
            if (empty($role->slug)) {
                $role->slug = Str::slug($role->name);
            }
        });
    }

    /**
     * A role belongs to many users
     */
    public function users(): BelongsToMany
    {
        return $this->belongsToMany(User::class, 'role_user')
            ->withPivot('assigned_at', 'assigned_by', 'expires_at')
            ->withTimestamps();
    }

    /**
     * A role has many permissions
     */
    public function permissions(): BelongsToMany
    {
        return $this->belongsToMany(Permission::class, 'permission_role')
            ->withPivot('assigned_at', 'assigned_by')
            ->withTimestamps();
    }

    /**
     * Check if role has a specific permission
     */
    public function hasPermission(string|Permission $permission): bool
    {
        if ($permission instanceof Permission) {
            $permission = $permission->slug;
        }

        return $this->permissions()
            ->where('permissions.slug', $permission)
            ->where('permissions.is_active', true)
            ->exists();
    }

    /**
     * Check if role has any of the given permissions
     */
    public function hasAnyPermission(array $permissions): bool
    {
        return $this->permissions()
            ->whereIn('permissions.slug', $permissions)
            ->where('permissions.is_active', true)
            ->exists();
    }

    /**
     * Check if role has all of the given permissions
     */
    public function hasAllPermissions(array $permissions): bool
    {
        $count = $this->permissions()
            ->whereIn('permissions.slug', $permissions)
            ->where('permissions.is_active', true)
            ->count();

        return $count === count($permissions);
    }

    /**
     * Give permission to role
     */
    public function givePermissionTo(string|Permission|array $permissions): self
    {
        $permissions = $this->normalizePermissions($permissions);
        
        $permissionIds = Permission::whereIn('slug', $permissions)->pluck('id');
        
        $this->permissions()->syncWithoutDetaching($permissionIds);

        return $this;
    }

    /**
     * Revoke permission from role
     */
    public function revokePermissionTo(string|Permission|array $permissions): self
    {
        $permissions = $this->normalizePermissions($permissions);
        
        $permissionIds = Permission::whereIn('slug', $permissions)->pluck('id');
        
        $this->permissions()->detach($permissionIds);

        return $this;
    }

    /**
     * Sync permissions (remove all existing and add new ones)
     */
    public function syncPermissions(array $permissions): self
    {
        $permissions = $this->normalizePermissions($permissions);
        
        $permissionIds = Permission::whereIn('slug', $permissions)->pluck('id');
        
        $this->permissions()->sync($permissionIds);

        return $this;
    }

    /**
     * Get all permission slugs for this role
     */
    public function getPermissionSlugs(): array
    {
        return $this->permissions()
            ->where('permissions.is_active', true)
            ->pluck('permissions.slug')
            ->toArray();
    }

    /**
     * Check if this role has higher level than another role
     */
    public function hasHigherLevelThan(Role $role): bool
    {
        return $this->level > $role->level;
    }

    /**
     * Check if this role has lower level than another role
     */
    public function hasLowerLevelThan(Role $role): bool
    {
        return $this->level < $role->level;
    }

    /**
     * Scope to get only active roles
     */
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    /**
     * Scope to get roles by level
     */
    public function scopeByLevel($query, int $level)
    {
        return $query->where('level', $level);
    }

    /**
     * Scope to get roles above a certain level
     */
    public function scopeAboveLevel($query, int $level)
    {
        return $query->where('level', '>', $level);
    }

    /**
     * Scope to get roles below a certain level
     */
    public function scopeBelowLevel($query, int $level)
    {
        return $query->where('level', '<', $level);
    }

    /**
     * Normalize permissions to array of slugs
     */
    protected function normalizePermissions(string|Permission|array $permissions): array
    {
        if (!is_array($permissions)) {
            $permissions = [$permissions];
        }

        return collect($permissions)->map(function ($permission) {
            if ($permission instanceof Permission) {
                return $permission->slug;
            }
            return $permission;
        })->toArray();
    }

    /**
     * Get the route key for the model
     */
    public function getRouteKeyName(): string
    {
        return 'slug';
    }
}
