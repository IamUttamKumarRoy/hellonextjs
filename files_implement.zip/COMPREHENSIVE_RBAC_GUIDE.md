# Comprehensive RBAC Seeder - Complete Documentation

## 📊 Overview

This seeder creates a complete RBAC system with **250+ permissions** across **22 modules** for a full-featured application.

---

## 🎯 What's Included

### **250+ Permissions** Organized in 22 Modules:

1. **Dashboard** (4 permissions)
   - View Dashboard, Analytics, Reports, Export Data

2. **Users** (15 permissions)
   - Complete user management including impersonation, ban/unban, import/export

3. **Roles** (7 permissions)
   - Full role CRUD with permission management and cloning

4. **Permissions** (6 permissions)
   - Permission management and synchronization

5. **Posts/Blog** (16 permissions)
   - Complete blog management with scheduling, featuring, moderation

6. **Categories** (7 permissions)
   - Category management with reordering and restoration

7. **Tags** (5 permissions)
   - Tag management including merging duplicates

8. **Comments** (11 permissions)
   - Full comment system with moderation and pinning

9. **Media/Files** (7 permissions)
   - Media library with organization and access control

10. **Pages** (5 permissions)
    - Static page management

11. **Menus** (5 permissions)
    - Navigation menu builder

12. **Products** (11 permissions)
    - E-commerce product management with inventory

13. **Orders** (10 permissions)
    - Order processing, refunds, and history

14. **Customers** (7 permissions)
    - Customer relationship management

15. **Coupons** (5 permissions)
    - Discount and coupon system

16. **Reports** (8 permissions)
    - Comprehensive reporting system

17. **Settings** (10 permissions)
    - Application configuration

18. **Notifications** (5 permissions)
    - Notification system

19. **Emails** (4 permissions)
    - Email management and templates

20. **Backups** (5 permissions)
    - Backup and restore functionality

21. **Activity Logs** (4 permissions)
    - User activity tracking

22. **Tickets/Support** (9 permissions)
    - Customer support ticketing system

23. **Newsletter** (7 permissions)
    - Email marketing campaigns

24. **SEO** (4 permissions)
    - Search engine optimization tools

25. **API** (5 permissions)
    - API key and rate limit management

---

## 👥 10 Pre-configured Roles

| Role | Level | Permissions Count | Description |
|------|-------|-------------------|-------------|
| Super Admin | 100 | ALL (250+) | Complete system access |
| Admin | 90 | ~247 | Nearly full access (excludes critical system ops) |
| Manager | 70 | ~120 | Comprehensive management capabilities |
| Editor | 50 | ~45 | Full content management |
| Author | 30 | ~12 | Own content creation |
| Moderator | 40 | ~15 | Content and comment moderation |
| Support | 35 | ~25 | Customer support operations |
| Customer | 15 | ~10 | E-commerce shopping |
| User | 10 | ~8 | Basic registered user |
| Guest | 1 | ~7 | Public access only |

---

## 🔐 11 Test Users with Examples

### Standard Users (1 role each)
1. **superadmin@example.com** - Super Admin
2. **admin@example.com** - Administrator
3. **manager@example.com** - Manager
4. **editor@example.com** - Editor
5. **author@example.com** - Author (+ direct publish permission)
6. **moderator@example.com** - Moderator (+ extra edit/delete permissions)
7. **support@example.com** - Support Agent (+ order processing)
8. **customer@example.com** - Customer (+ 30-day premium reports)
9. **user@example.com** - User (+ 7-day trial content creation)

### Special Users (demonstrating advanced features)
10. **multirole@example.com** - Editor + Moderator + API access
11. **temprole@example.com** - User + Temporary Customer role (30 days)

---

## 🚀 Installation & Usage

### Step 1: Run the Seeder

```bash
# Run the comprehensive seeder
php artisan db:seed --class=ComprehensiveRbacSeeder
```

### Step 2: Verify Installation

```bash
# Check permissions count
php artisan tinker
>>> Permission::count();
=> 250+ 

# Check roles
>>> Role::pluck('name', 'slug');

# Check a user's permissions
>>> User::where('email', 'editor@example.com')->first()->getAllPermissions()->count();
```

---

## 💡 Usage Examples

### Example 1: Check User Permissions

```php
$user = User::where('email', 'editor@example.com')->first();

// Check single permission
if ($user->hasPermission('posts.publish')) {
    // User can publish posts
}

// Check multiple permissions (any)
if ($user->hasAnyPermission(['posts.edit', 'posts.delete'])) {
    // User can edit OR delete
}

// Check multiple permissions (all)
if ($user->hasAllPermissions(['posts.create', 'posts.publish'])) {
    // User can both create AND publish
}

// Get all permissions
$permissions = $user->getAllPermissions();
$permissionSlugs = $user->getPermissionSlugs();
```

### Example 2: Check User Roles

```php
$user = User::find(1);

// Check single role
if ($user->hasRole('admin')) {
    // User is admin
}

// Check multiple roles
if ($user->hasAnyRole(['admin', 'manager'])) {
    // User is admin OR manager
}

// Get all roles
$roles = $user->getActiveRoles();
$roleSlugs = $user->getRoleSlugs();
```

### Example 3: Protect Routes

```php
// routes/web.php

// Single role protection
Route::middleware(['auth', 'role:admin'])->group(function () {
    Route::get('/admin/dashboard', [AdminController::class, 'index']);
});

// Multiple roles (user needs ANY)
Route::middleware(['auth', 'role:admin,manager'])->group(function () {
    Route::resource('users', UserController::class);
});

// Permission protection
Route::middleware(['auth', 'permission:posts.create'])->group(function () {
    Route::get('/posts/create', [PostController::class, 'create']);
});

// Multiple permissions
Route::middleware(['auth', 'permission:products.create,products.edit'])->group(function () {
    Route::resource('products', ProductController::class);
});

// Combine role and permission
Route::middleware(['auth', 'role:manager', 'permission:users.delete'])->group(function () {
    Route::delete('/users/{user}', [UserController::class, 'destroy']);
});
```

### Example 4: Controller Authorization

```php
namespace App\Http\Controllers;

class PostController extends Controller
{
    public function index()
    {
        // Check permission
        if (!auth()->user()->hasPermission('posts.view')) {
            abort(403, 'Unauthorized');
        }

        $posts = Post::all();
        return view('posts.index', compact('posts'));
    }

    public function create()
    {
        // Alternative check
        abort_unless(auth()->user()->hasPermission('posts.create'), 403);

        return view('posts.create');
    }

    public function store(Request $request)
    {
        $user = auth()->user();

        // Check if can publish directly
        if ($user->hasPermission('posts.publish')) {
            $status = 'published';
        } else {
            $status = 'draft';
        }

        $post = Post::create([
            'title' => $request->title,
            'content' => $request->content,
            'status' => $status,
            'user_id' => $user->id,
        ]);

        return redirect()->route('posts.show', $post);
    }

    public function destroy(Post $post)
    {
        $user = auth()->user();

        // Can delete all posts OR own post
        if (!$user->hasPermission('posts.delete') 
            && !($user->hasPermission('posts.delete-own') && $post->user_id === $user->id)) {
            abort(403);
        }

        $post->delete();
        return redirect()->route('posts.index');
    }
}
```

### Example 5: Blade Directives

```blade
{{-- Single role check --}}
@role('admin')
    <div class="admin-panel">
        <h2>Admin Controls</h2>
        <a href="{{ route('admin.settings') }}">Settings</a>
    </div>
@endrole

{{-- Multiple roles --}}
@anyrole(['admin', 'manager'])
    <a href="{{ route('users.index') }}" class="nav-link">Manage Users</a>
@endanyrole

{{-- Permission check --}}
@permission('posts.create')
    <a href="{{ route('posts.create') }}" class="btn btn-primary">
        Create New Post
    </a>
@endpermission

{{-- Multiple permissions --}}
@anypermission(['products.edit', 'products.delete'])
    <div class="product-actions">
        @permission('products.edit')
            <a href="{{ route('products.edit', $product) }}">Edit</a>
        @endpermission
        
        @permission('products.delete')
            <form action="{{ route('products.destroy', $product) }}" method="POST">
                @csrf @method('DELETE')
                <button type="submit">Delete</button>
            </form>
        @endpermission
    </div>
@endanypermission

{{-- With else condition --}}
@role('admin')
    <p>Welcome, Administrator!</p>
@else
    <p>You don't have admin access</p>
@endrole

{{-- Nested conditions --}}
@role('manager')
    <div class="manager-dashboard">
        @permission('users.create')
            <button>Add User</button>
        @endpermission
        
        @permission('reports.view')
            <a href="{{ route('reports.index') }}">View Reports</a>
        @endpermission
    </div>
@endrole
```

### Example 6: Advanced - Temporary Permissions

```php
// Give user temporary access for 30 days
$user = User::find(1);
$user->givePermissionTo('premium.features', [
    'expires_at' => now()->addDays(30)
]);

// Check if still valid (automatically handled)
if ($user->hasPermission('premium.features')) {
    // Permission is still active
}

// Assign temporary role
$user->assignRole('trial-premium', [
    'expires_at' => now()->addDays(7)
]);
```

### Example 7: Advanced - Forbidden Permissions

```php
// Explicitly deny a permission (overrides role permissions)
$user = User::find(1);
$user->assignRole('editor'); // Has posts.delete through role

// Forbid this specific user from deleting
$user->forbidPermission('posts.delete');

// Now returns false even though editor role has this permission
$user->hasPermission('posts.delete'); // false

// Remove the forbid
$user->unforbidPermission('posts.delete');
```

### Example 8: Query Users by Role/Permission

```php
// Get all admins
$admins = User::withRole('admin')->get();

// Get all users with multiple roles
$editors = User::withRole(['editor', 'author'])->get();

// Get users with specific permission
$publishers = User::withPermission('posts.publish')->get();

// Get users who can delete posts
$canDelete = User::whereHas('roles', function($query) {
    $query->whereHas('permissions', function($q) {
        $q->where('slug', 'posts.delete');
    });
})->orWhereHas('permissions', function($query) {
    $query->where('slug', 'posts.delete')
          ->where('is_forbidden', false);
})->get();
```

### Example 9: Permission Management

```php
// Add permission to role
$role = Role::where('slug', 'editor')->first();
$role->givePermissionTo('posts.publish');
$role->givePermissionTo(['posts.schedule', 'posts.feature']);

// Remove permission from role
$role->revokePermissionTo('posts.delete');

// Sync permissions (replace all)
$role->syncPermissions([
    'posts.view',
    'posts.create',
    'posts.edit',
    'posts.publish'
]);

// Check role permissions
if ($role->hasPermission('posts.create')) {
    // Role has this permission
}

// Get all permissions for a role
$permissions = $role->getPermissionSlugs();
```

### Example 10: User Management

```php
// Assign role to user
$user = User::find(1);
$user->assignRole('editor');
$user->assignRole(['moderator', 'support']);

// Remove role
$user->removeRole('moderator');

// Sync roles (replace all)
$user->syncRoles(['editor', 'author']);

// Give direct permission
$user->givePermissionTo('posts.feature');
$user->givePermissionTo(['media.upload', 'media.delete']);

// Revoke direct permission
$user->revokePermissionTo('media.delete');

// Get all user permissions (from roles + direct)
$allPermissions = $user->getAllPermissions();
$permissionSlugs = $user->getPermissionSlugs();
```

---

## 🎨 Permission Groups

Permissions are organized by groups for easy management:

```php
// Get all permission groups
$groups = Permission::getAllGroups();

// Get permissions by group
$userPermissions = Permission::byGroup('Users')->get();
$postPermissions = Permission::byGroup('Posts')->get();

// Get permissions in multiple groups
$contentPermissions = Permission::inGroups(['Posts', 'Pages', 'Media'])->get();

// Display grouped permissions
foreach (Permission::getAllGroups() as $group) {
    echo "Group: {$group}\n";
    $permissions = Permission::byGroup($group)->get();
    foreach ($permissions as $permission) {
        echo "  - {$permission->name} ({$permission->slug})\n";
    }
}
```

---

## 📈 Role Hierarchy

Roles have levels for hierarchy management:

```php
$adminRole = Role::where('slug', 'admin')->first(); // Level 90
$userRole = Role::where('slug', 'user')->first();   // Level 10

// Check hierarchy
if ($adminRole->hasHigherLevelThan($userRole)) {
    // Admin has higher level
}

// Get roles above certain level
$seniorRoles = Role::aboveLevel(50)->get(); // Admin, Manager, Editor

// Get roles below certain level
$juniorRoles = Role::belowLevel(50)->get(); // Author, Support, User, etc.

// Get roles at specific level
$level50Roles = Role::byLevel(50)->get(); // Editor
```

---

## 🧪 Testing Examples

```php
namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;

class RbacTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(\Database\Seeders\ComprehensiveRbacSeeder::class);
    }

    public function test_super_admin_has_all_permissions()
    {
        $user = User::where('email', 'superadmin@example.com')->first();
        
        $this->assertTrue($user->hasRole('super-admin'));
        $this->assertTrue($user->hasPermission('users.delete'));
        $this->assertTrue($user->hasPermission('backups.restore'));
        $this->assertGreaterThan(200, $user->getAllPermissions()->count());
    }

    public function test_editor_can_publish_posts()
    {
        $user = User::where('email', 'editor@example.com')->first();
        
        $this->assertTrue($user->hasPermission('posts.publish'));
        $this->assertTrue($user->hasPermission('posts.create'));
    }

    public function test_author_can_only_edit_own_posts()
    {
        $user = User::where('email', 'author@example.com')->first();
        
        $this->assertTrue($user->hasPermission('posts.edit-own'));
        $this->assertFalse($user->hasPermission('posts.edit'));
    }

    public function test_forbidden_permission_overrides_role()
    {
        $user = User::where('email', 'editor@example.com')->first();
        
        $this->assertFalse($user->hasPermission('posts.delete')); // Forbidden
    }

    public function test_temporary_permission_expires()
    {
        $user = User::where('email', 'user@example.com')->first();
        
        $this->assertTrue($user->hasPermission('posts.create')); // 7-day trial
        
        // Travel forward 8 days
        $this->travel(8)->days();
        
        $this->assertFalse($user->hasPermission('posts.create')); // Expired
    }

    public function test_middleware_blocks_unauthorized_user()
    {
        $user = User::where('email', 'user@example.com')->first();
        
        $response = $this->actingAs($user)->get('/admin/dashboard');
        $response->assertStatus(403);
    }

    public function test_middleware_allows_authorized_user()
    {
        $user = User::where('email', 'admin@example.com')->first();
        
        $response = $this->actingAs($user)->get('/admin/dashboard');
        $response->assertStatus(200);
    }
}
```

---

## 📊 Statistics

After running the seeder, you'll have:

- **250+ Permissions** across 22 modules
- **10 Roles** with complete hierarchy
- **11 Test Users** with various configurations
- **Direct Permission Examples** (6 users)
- **Forbidden Permission Example** (1 user)
- **Temporary Permission Examples** (2 users)
- **Temporary Role Example** (1 user)
- **Multi-Role Example** (1 user)

---

## 🔧 Customization

### Add More Permissions

```php
// In the createAllPermissions() method, add to $permissionsData array:

'Your Module' => [
    ['name' => 'Your Permission', 'slug' => 'your.permission', 'description' => 'Description'],
],
```

### Modify Role Permissions

```php
// In the assignPermissionsToRoles() method:

$roles['your-role']->syncPermissions([
    'permission.one',
    'permission.two',
    // ...
]);
```

### Create Additional Users

```php
// In the createUsers() method:

$users['custom'] = User::create([
    'name' => 'Custom User',
    'email' => 'custom@example.com',
    'password' => Hash::make('password'),
    'email_verified_at' => now(),
]);
$users['custom']->assignRole('your-role');
```

---

## ✅ Best Practices

1. **Use Role Slugs**: Always use slugs for checking roles and permissions
2. **Cache Awareness**: Permissions are cached automatically for 1 hour
3. **Forbidden Sparingly**: Use forbidden permissions only when absolutely necessary
4. **Temporary Access**: Perfect for trials, promotions, or time-limited features
5. **Middleware First**: Always protect routes with middleware, not just controller checks
6. **Test Thoroughly**: Write tests for your RBAC logic
7. **Document Custom Permissions**: Keep your permission list documented

---

## 🎯 Summary

This comprehensive seeder provides a production-ready RBAC system with:

✅ 250+ permissions covering all common application needs
✅ 10 pre-configured roles with proper hierarchy
✅ 11 example users demonstrating all features
✅ Support for temporary access
✅ Permission forbidding capability
✅ Multi-role assignments
✅ Direct user permissions
✅ Permission grouping and organization

All configured and ready to use! Just run the seeder and start building your application.
