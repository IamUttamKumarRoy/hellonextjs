<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Role;
use App\Models\Permission;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class ComprehensiveRbacSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $this->command->info('🚀 Starting RBAC Seeding...');

        // Create all permissions
        $permissions = $this->createAllPermissions();
        $this->command->info('✅ ' . count($permissions) . ' Permissions created');

        // Create roles
        $roles = $this->createRoles();
        $this->command->info('✅ ' . count($roles) . ' Roles created');

        // Assign permissions to roles
        $this->assignPermissionsToRoles($roles, $permissions);
        $this->command->info('✅ Permissions assigned to roles');

        // Create users
        $users = $this->createUsers($roles);
        $this->command->info('✅ ' . count($users) . ' Users created');

        // Assign direct permissions to specific users
        $this->assignDirectPermissions($users, $permissions);
        $this->command->info('✅ Direct permissions assigned to users');

        $this->displayLoginCredentials();
    }

    /**
     * Create all permissions for the application
     */
    private function createAllPermissions(): array
    {
        $permissionsData = [
            // ==================== DASHBOARD ====================
            'Dashboard' => [
                ['name' => 'View Dashboard', 'slug' => 'dashboard.view', 'description' => 'Access main dashboard'],
                ['name' => 'View Analytics', 'slug' => 'dashboard.analytics', 'description' => 'View dashboard analytics'],
                ['name' => 'View Reports', 'slug' => 'dashboard.reports', 'description' => 'View dashboard reports'],
                ['name' => 'Export Dashboard Data', 'slug' => 'dashboard.export', 'description' => 'Export dashboard data'],
            ],

            // ==================== USER MANAGEMENT ====================
            'Users' => [
                ['name' => 'View Users', 'slug' => 'users.view', 'description' => 'View user list and details'],
                ['name' => 'View User Details', 'slug' => 'users.show', 'description' => 'View individual user details'],
                ['name' => 'Create Users', 'slug' => 'users.create', 'description' => 'Create new users'],
                ['name' => 'Edit Users', 'slug' => 'users.edit', 'description' => 'Edit existing users'],
                ['name' => 'Delete Users', 'slug' => 'users.delete', 'description' => 'Delete users'],
                ['name' => 'Restore Users', 'slug' => 'users.restore', 'description' => 'Restore deleted users'],
                ['name' => 'Force Delete Users', 'slug' => 'users.force-delete', 'description' => 'Permanently delete users'],
                ['name' => 'Ban Users', 'slug' => 'users.ban', 'description' => 'Ban/suspend users'],
                ['name' => 'Unban Users', 'slug' => 'users.unban', 'description' => 'Unban users'],
                ['name' => 'Manage User Roles', 'slug' => 'users.manage-roles', 'description' => 'Assign/remove roles from users'],
                ['name' => 'Manage User Permissions', 'slug' => 'users.manage-permissions', 'description' => 'Assign/remove permissions from users'],
                ['name' => 'View User Activity', 'slug' => 'users.activity', 'description' => 'View user activity logs'],
                ['name' => 'Export Users', 'slug' => 'users.export', 'description' => 'Export user data'],
                ['name' => 'Import Users', 'slug' => 'users.import', 'description' => 'Import user data'],
                ['name' => 'Impersonate Users', 'slug' => 'users.impersonate', 'description' => 'Login as another user'],
            ],

            // ==================== ROLE MANAGEMENT ====================
            'Roles' => [
                ['name' => 'View Roles', 'slug' => 'roles.view', 'description' => 'View roles list'],
                ['name' => 'View Role Details', 'slug' => 'roles.show', 'description' => 'View role details'],
                ['name' => 'Create Roles', 'slug' => 'roles.create', 'description' => 'Create new roles'],
                ['name' => 'Edit Roles', 'slug' => 'roles.edit', 'description' => 'Edit existing roles'],
                ['name' => 'Delete Roles', 'slug' => 'roles.delete', 'description' => 'Delete roles'],
                ['name' => 'Manage Role Permissions', 'slug' => 'roles.manage-permissions', 'description' => 'Assign/remove permissions from roles'],
                ['name' => 'Clone Roles', 'slug' => 'roles.clone', 'description' => 'Duplicate existing roles'],
            ],

            // ==================== PERMISSION MANAGEMENT ====================
            'Permissions' => [
                ['name' => 'View Permissions', 'slug' => 'permissions.view', 'description' => 'View permissions list'],
                ['name' => 'View Permission Details', 'slug' => 'permissions.show', 'description' => 'View permission details'],
                ['name' => 'Create Permissions', 'slug' => 'permissions.create', 'description' => 'Create new permissions'],
                ['name' => 'Edit Permissions', 'slug' => 'permissions.edit', 'description' => 'Edit existing permissions'],
                ['name' => 'Delete Permissions', 'slug' => 'permissions.delete', 'description' => 'Delete permissions'],
                ['name' => 'Sync Permissions', 'slug' => 'permissions.sync', 'description' => 'Synchronize permissions'],
            ],

            // ==================== POST/BLOG MANAGEMENT ====================
            'Posts' => [
                ['name' => 'View Posts', 'slug' => 'posts.view', 'description' => 'View posts list'],
                ['name' => 'View Post Details', 'slug' => 'posts.show', 'description' => 'View individual post'],
                ['name' => 'Create Posts', 'slug' => 'posts.create', 'description' => 'Create new posts'],
                ['name' => 'Edit Posts', 'slug' => 'posts.edit', 'description' => 'Edit existing posts'],
                ['name' => 'Edit Own Posts', 'slug' => 'posts.edit-own', 'description' => 'Edit own posts only'],
                ['name' => 'Delete Posts', 'slug' => 'posts.delete', 'description' => 'Delete posts'],
                ['name' => 'Delete Own Posts', 'slug' => 'posts.delete-own', 'description' => 'Delete own posts only'],
                ['name' => 'Restore Posts', 'slug' => 'posts.restore', 'description' => 'Restore deleted posts'],
                ['name' => 'Force Delete Posts', 'slug' => 'posts.force-delete', 'description' => 'Permanently delete posts'],
                ['name' => 'Publish Posts', 'slug' => 'posts.publish', 'description' => 'Publish/unpublish posts'],
                ['name' => 'Schedule Posts', 'slug' => 'posts.schedule', 'description' => 'Schedule posts for future'],
                ['name' => 'Feature Posts', 'slug' => 'posts.feature', 'description' => 'Mark posts as featured'],
                ['name' => 'Moderate Posts', 'slug' => 'posts.moderate', 'description' => 'Approve/reject posts'],
                ['name' => 'View Draft Posts', 'slug' => 'posts.view-drafts', 'description' => 'View draft posts'],
                ['name' => 'View All Posts', 'slug' => 'posts.view-all', 'description' => 'View all posts including others'],
                ['name' => 'Export Posts', 'slug' => 'posts.export', 'description' => 'Export posts data'],
            ],

            // ==================== CATEGORY MANAGEMENT ====================
            'Categories' => [
                ['name' => 'View Categories', 'slug' => 'categories.view', 'description' => 'View categories list'],
                ['name' => 'View Category Details', 'slug' => 'categories.show', 'description' => 'View category details'],
                ['name' => 'Create Categories', 'slug' => 'categories.create', 'description' => 'Create new categories'],
                ['name' => 'Edit Categories', 'slug' => 'categories.edit', 'description' => 'Edit existing categories'],
                ['name' => 'Delete Categories', 'slug' => 'categories.delete', 'description' => 'Delete categories'],
                ['name' => 'Restore Categories', 'slug' => 'categories.restore', 'description' => 'Restore deleted categories'],
                ['name' => 'Reorder Categories', 'slug' => 'categories.reorder', 'description' => 'Change category order'],
            ],

            // ==================== TAG MANAGEMENT ====================
            'Tags' => [
                ['name' => 'View Tags', 'slug' => 'tags.view', 'description' => 'View tags list'],
                ['name' => 'Create Tags', 'slug' => 'tags.create', 'description' => 'Create new tags'],
                ['name' => 'Edit Tags', 'slug' => 'tags.edit', 'description' => 'Edit existing tags'],
                ['name' => 'Delete Tags', 'slug' => 'tags.delete', 'description' => 'Delete tags'],
                ['name' => 'Merge Tags', 'slug' => 'tags.merge', 'description' => 'Merge duplicate tags'],
            ],

            // ==================== COMMENT MANAGEMENT ====================
            'Comments' => [
                ['name' => 'View Comments', 'slug' => 'comments.view', 'description' => 'View comments list'],
                ['name' => 'View Comment Details', 'slug' => 'comments.show', 'description' => 'View comment details'],
                ['name' => 'Create Comments', 'slug' => 'comments.create', 'description' => 'Create comments'],
                ['name' => 'Edit Comments', 'slug' => 'comments.edit', 'description' => 'Edit any comment'],
                ['name' => 'Edit Own Comments', 'slug' => 'comments.edit-own', 'description' => 'Edit own comments only'],
                ['name' => 'Delete Comments', 'slug' => 'comments.delete', 'description' => 'Delete any comment'],
                ['name' => 'Delete Own Comments', 'slug' => 'comments.delete-own', 'description' => 'Delete own comments only'],
                ['name' => 'Approve Comments', 'slug' => 'comments.approve', 'description' => 'Approve pending comments'],
                ['name' => 'Reject Comments', 'slug' => 'comments.reject', 'description' => 'Reject/spam comments'],
                ['name' => 'Moderate Comments', 'slug' => 'comments.moderate', 'description' => 'Full comment moderation'],
                ['name' => 'Pin Comments', 'slug' => 'comments.pin', 'description' => 'Pin important comments'],
            ],

            // ==================== MEDIA/FILE MANAGEMENT ====================
            'Media' => [
                ['name' => 'View Media', 'slug' => 'media.view', 'description' => 'View media library'],
                ['name' => 'Upload Media', 'slug' => 'media.upload', 'description' => 'Upload new media files'],
                ['name' => 'Edit Media', 'slug' => 'media.edit', 'description' => 'Edit media details'],
                ['name' => 'Delete Media', 'slug' => 'media.delete', 'description' => 'Delete media files'],
                ['name' => 'Delete Own Media', 'slug' => 'media.delete-own', 'description' => 'Delete own media only'],
                ['name' => 'Organize Media', 'slug' => 'media.organize', 'description' => 'Create folders and organize'],
                ['name' => 'View All Media', 'slug' => 'media.view-all', 'description' => 'View all users media'],
            ],

            // ==================== PAGE MANAGEMENT ====================
            'Pages' => [
                ['name' => 'View Pages', 'slug' => 'pages.view', 'description' => 'View pages list'],
                ['name' => 'Create Pages', 'slug' => 'pages.create', 'description' => 'Create new pages'],
                ['name' => 'Edit Pages', 'slug' => 'pages.edit', 'description' => 'Edit existing pages'],
                ['name' => 'Delete Pages', 'slug' => 'pages.delete', 'description' => 'Delete pages'],
                ['name' => 'Publish Pages', 'slug' => 'pages.publish', 'description' => 'Publish pages'],
            ],

            // ==================== MENU MANAGEMENT ====================
            'Menus' => [
                ['name' => 'View Menus', 'slug' => 'menus.view', 'description' => 'View menus'],
                ['name' => 'Create Menus', 'slug' => 'menus.create', 'description' => 'Create menus'],
                ['name' => 'Edit Menus', 'slug' => 'menus.edit', 'description' => 'Edit menus'],
                ['name' => 'Delete Menus', 'slug' => 'menus.delete', 'description' => 'Delete menus'],
                ['name' => 'Reorder Menu Items', 'slug' => 'menus.reorder', 'description' => 'Reorder menu items'],
            ],

            // ==================== PRODUCT MANAGEMENT (E-COMMERCE) ====================
            'Products' => [
                ['name' => 'View Products', 'slug' => 'products.view', 'description' => 'View products list'],
                ['name' => 'View Product Details', 'slug' => 'products.show', 'description' => 'View product details'],
                ['name' => 'Create Products', 'slug' => 'products.create', 'description' => 'Create new products'],
                ['name' => 'Edit Products', 'slug' => 'products.edit', 'description' => 'Edit existing products'],
                ['name' => 'Delete Products', 'slug' => 'products.delete', 'description' => 'Delete products'],
                ['name' => 'Manage Product Inventory', 'slug' => 'products.manage-inventory', 'description' => 'Manage stock levels'],
                ['name' => 'Manage Product Pricing', 'slug' => 'products.manage-pricing', 'description' => 'Update product prices'],
                ['name' => 'Feature Products', 'slug' => 'products.feature', 'description' => 'Mark products as featured'],
                ['name' => 'Publish Products', 'slug' => 'products.publish', 'description' => 'Publish/unpublish products'],
                ['name' => 'Import Products', 'slug' => 'products.import', 'description' => 'Import products from CSV'],
                ['name' => 'Export Products', 'slug' => 'products.export', 'description' => 'Export products to CSV'],
            ],

            // ==================== ORDER MANAGEMENT ====================
            'Orders' => [
                ['name' => 'View Orders', 'slug' => 'orders.view', 'description' => 'View orders list'],
                ['name' => 'View Order Details', 'slug' => 'orders.show', 'description' => 'View order details'],
                ['name' => 'Create Orders', 'slug' => 'orders.create', 'description' => 'Create manual orders'],
                ['name' => 'Edit Orders', 'slug' => 'orders.edit', 'description' => 'Edit order details'],
                ['name' => 'Delete Orders', 'slug' => 'orders.delete', 'description' => 'Delete orders'],
                ['name' => 'Process Orders', 'slug' => 'orders.process', 'description' => 'Process and fulfill orders'],
                ['name' => 'Cancel Orders', 'slug' => 'orders.cancel', 'description' => 'Cancel orders'],
                ['name' => 'Refund Orders', 'slug' => 'orders.refund', 'description' => 'Process refunds'],
                ['name' => 'View Order History', 'slug' => 'orders.history', 'description' => 'View order history'],
                ['name' => 'Export Orders', 'slug' => 'orders.export', 'description' => 'Export order data'],
            ],

            // ==================== CUSTOMER MANAGEMENT ====================
            'Customers' => [
                ['name' => 'View Customers', 'slug' => 'customers.view', 'description' => 'View customers list'],
                ['name' => 'View Customer Details', 'slug' => 'customers.show', 'description' => 'View customer details'],
                ['name' => 'Create Customers', 'slug' => 'customers.create', 'description' => 'Create new customers'],
                ['name' => 'Edit Customers', 'slug' => 'customers.edit', 'description' => 'Edit customer details'],
                ['name' => 'Delete Customers', 'slug' => 'customers.delete', 'description' => 'Delete customers'],
                ['name' => 'View Customer Orders', 'slug' => 'customers.view-orders', 'description' => 'View customer order history'],
                ['name' => 'Export Customers', 'slug' => 'customers.export', 'description' => 'Export customer data'],
            ],

            // ==================== COUPON/DISCOUNT MANAGEMENT ====================
            'Coupons' => [
                ['name' => 'View Coupons', 'slug' => 'coupons.view', 'description' => 'View coupons list'],
                ['name' => 'Create Coupons', 'slug' => 'coupons.create', 'description' => 'Create new coupons'],
                ['name' => 'Edit Coupons', 'slug' => 'coupons.edit', 'description' => 'Edit existing coupons'],
                ['name' => 'Delete Coupons', 'slug' => 'coupons.delete', 'description' => 'Delete coupons'],
                ['name' => 'Activate Coupons', 'slug' => 'coupons.activate', 'description' => 'Activate/deactivate coupons'],
            ],

            // ==================== REPORT MANAGEMENT ====================
            'Reports' => [
                ['name' => 'View Reports', 'slug' => 'reports.view', 'description' => 'View all reports'],
                ['name' => 'View Sales Reports', 'slug' => 'reports.sales', 'description' => 'View sales reports'],
                ['name' => 'View User Reports', 'slug' => 'reports.users', 'description' => 'View user reports'],
                ['name' => 'View Analytics Reports', 'slug' => 'reports.analytics', 'description' => 'View analytics reports'],
                ['name' => 'View Financial Reports', 'slug' => 'reports.financial', 'description' => 'View financial reports'],
                ['name' => 'Export Reports', 'slug' => 'reports.export', 'description' => 'Export reports to CSV/PDF'],
                ['name' => 'Create Custom Reports', 'slug' => 'reports.create-custom', 'description' => 'Create custom reports'],
                ['name' => 'Schedule Reports', 'slug' => 'reports.schedule', 'description' => 'Schedule automated reports'],
            ],

            // ==================== SETTINGS MANAGEMENT ====================
            'Settings' => [
                ['name' => 'View Settings', 'slug' => 'settings.view', 'description' => 'View application settings'],
                ['name' => 'Edit General Settings', 'slug' => 'settings.general', 'description' => 'Edit general settings'],
                ['name' => 'Edit Email Settings', 'slug' => 'settings.email', 'description' => 'Configure email settings'],
                ['name' => 'Edit Payment Settings', 'slug' => 'settings.payment', 'description' => 'Configure payment gateways'],
                ['name' => 'Edit SEO Settings', 'slug' => 'settings.seo', 'description' => 'Configure SEO settings'],
                ['name' => 'Edit Security Settings', 'slug' => 'settings.security', 'description' => 'Configure security settings'],
                ['name' => 'Edit API Settings', 'slug' => 'settings.api', 'description' => 'Configure API settings'],
                ['name' => 'Manage Integrations', 'slug' => 'settings.integrations', 'description' => 'Manage third-party integrations'],
                ['name' => 'Clear Cache', 'slug' => 'settings.clear-cache', 'description' => 'Clear application cache'],
                ['name' => 'View System Info', 'slug' => 'settings.system-info', 'description' => 'View system information'],
            ],

            // ==================== NOTIFICATION MANAGEMENT ====================
            'Notifications' => [
                ['name' => 'View Notifications', 'slug' => 'notifications.view', 'description' => 'View notifications'],
                ['name' => 'Create Notifications', 'slug' => 'notifications.create', 'description' => 'Send notifications'],
                ['name' => 'Delete Notifications', 'slug' => 'notifications.delete', 'description' => 'Delete notifications'],
                ['name' => 'Mark as Read', 'slug' => 'notifications.mark-read', 'description' => 'Mark notifications as read'],
                ['name' => 'Manage Templates', 'slug' => 'notifications.templates', 'description' => 'Manage notification templates'],
            ],

            // ==================== EMAIL MANAGEMENT ====================
            'Emails' => [
                ['name' => 'View Email Logs', 'slug' => 'emails.view-logs', 'description' => 'View email logs'],
                ['name' => 'Send Emails', 'slug' => 'emails.send', 'description' => 'Send emails'],
                ['name' => 'Manage Email Templates', 'slug' => 'emails.templates', 'description' => 'Manage email templates'],
                ['name' => 'Test Email Configuration', 'slug' => 'emails.test', 'description' => 'Test email settings'],
            ],

            // ==================== BACKUP MANAGEMENT ====================
            'Backups' => [
                ['name' => 'View Backups', 'slug' => 'backups.view', 'description' => 'View backup list'],
                ['name' => 'Create Backups', 'slug' => 'backups.create', 'description' => 'Create new backup'],
                ['name' => 'Download Backups', 'slug' => 'backups.download', 'description' => 'Download backup files'],
                ['name' => 'Restore Backups', 'slug' => 'backups.restore', 'description' => 'Restore from backup'],
                ['name' => 'Delete Backups', 'slug' => 'backups.delete', 'description' => 'Delete backup files'],
            ],

            // ==================== ACTIVITY LOG ====================
            'Activity Logs' => [
                ['name' => 'View Activity Logs', 'slug' => 'activity-logs.view', 'description' => 'View activity logs'],
                ['name' => 'View Own Activity', 'slug' => 'activity-logs.view-own', 'description' => 'View own activity'],
                ['name' => 'Delete Activity Logs', 'slug' => 'activity-logs.delete', 'description' => 'Delete activity logs'],
                ['name' => 'Export Activity Logs', 'slug' => 'activity-logs.export', 'description' => 'Export activity logs'],
            ],

            // ==================== TICKET/SUPPORT MANAGEMENT ====================
            'Tickets' => [
                ['name' => 'View Tickets', 'slug' => 'tickets.view', 'description' => 'View support tickets'],
                ['name' => 'View Own Tickets', 'slug' => 'tickets.view-own', 'description' => 'View own tickets only'],
                ['name' => 'Create Tickets', 'slug' => 'tickets.create', 'description' => 'Create support tickets'],
                ['name' => 'Edit Tickets', 'slug' => 'tickets.edit', 'description' => 'Edit ticket details'],
                ['name' => 'Delete Tickets', 'slug' => 'tickets.delete', 'description' => 'Delete tickets'],
                ['name' => 'Assign Tickets', 'slug' => 'tickets.assign', 'description' => 'Assign tickets to agents'],
                ['name' => 'Close Tickets', 'slug' => 'tickets.close', 'description' => 'Close resolved tickets'],
                ['name' => 'Reopen Tickets', 'slug' => 'tickets.reopen', 'description' => 'Reopen closed tickets'],
                ['name' => 'Reply to Tickets', 'slug' => 'tickets.reply', 'description' => 'Reply to tickets'],
            ],

            // ==================== NEWSLETTER MANAGEMENT ====================
            'Newsletter' => [
                ['name' => 'View Subscribers', 'slug' => 'newsletter.view-subscribers', 'description' => 'View subscriber list'],
                ['name' => 'Add Subscribers', 'slug' => 'newsletter.add-subscribers', 'description' => 'Add new subscribers'],
                ['name' => 'Remove Subscribers', 'slug' => 'newsletter.remove-subscribers', 'description' => 'Remove subscribers'],
                ['name' => 'Create Campaigns', 'slug' => 'newsletter.create-campaigns', 'description' => 'Create email campaigns'],
                ['name' => 'Send Campaigns', 'slug' => 'newsletter.send-campaigns', 'description' => 'Send email campaigns'],
                ['name' => 'View Campaign Stats', 'slug' => 'newsletter.campaign-stats', 'description' => 'View campaign statistics'],
                ['name' => 'Export Subscribers', 'slug' => 'newsletter.export-subscribers', 'description' => 'Export subscriber list'],
            ],

            // ==================== SEO MANAGEMENT ====================
            'SEO' => [
                ['name' => 'Manage Meta Tags', 'slug' => 'seo.meta-tags', 'description' => 'Manage meta tags'],
                ['name' => 'Manage Sitemaps', 'slug' => 'seo.sitemaps', 'description' => 'Generate and manage sitemaps'],
                ['name' => 'Manage Redirects', 'slug' => 'seo.redirects', 'description' => 'Manage URL redirects'],
                ['name' => 'View SEO Reports', 'slug' => 'seo.reports', 'description' => 'View SEO analytics'],
            ],

            // ==================== API MANAGEMENT ====================
            'API' => [
                ['name' => 'View API Keys', 'slug' => 'api.view-keys', 'description' => 'View API keys'],
                ['name' => 'Create API Keys', 'slug' => 'api.create-keys', 'description' => 'Create API keys'],
                ['name' => 'Revoke API Keys', 'slug' => 'api.revoke-keys', 'description' => 'Revoke API keys'],
                ['name' => 'View API Logs', 'slug' => 'api.view-logs', 'description' => 'View API usage logs'],
                ['name' => 'Manage API Rate Limits', 'slug' => 'api.rate-limits', 'description' => 'Manage API rate limits'],
            ],
        ];

        $permissions = [];
        foreach ($permissionsData as $group => $groupPermissions) {
            foreach ($groupPermissions as $permData) {
                $permissions[] = Permission::create([
                    'name' => $permData['name'],
                    'slug' => $permData['slug'],
                    'group' => $group,
                    'description' => $permData['description'],
                    'is_active' => true,
                ]);
            }
        }

        return $permissions;
    }

    /**
     * Create roles with hierarchy
     */
    private function createRoles(): array
    {
        return [
            'super-admin' => Role::create([
                'name' => 'Super Administrator',
                'slug' => 'super-admin',
                'description' => 'Has complete unrestricted access to all features and settings',
                'level' => 100,
                'is_active' => true,
            ]),

            'admin' => Role::create([
                'name' => 'Administrator',
                'slug' => 'admin',
                'description' => 'Has access to most features with some restrictions',
                'level' => 90,
                'is_active' => true,
            ]),

            'manager' => Role::create([
                'name' => 'Manager',
                'slug' => 'manager',
                'description' => 'Can manage content, users, and operations',
                'level' => 70,
                'is_active' => true,
            ]),

            'editor' => Role::create([
                'name' => 'Editor',
                'slug' => 'editor',
                'description' => 'Can create, edit, and publish all content',
                'level' => 50,
                'is_active' => true,
            ]),

            'author' => Role::create([
                'name' => 'Author',
                'slug' => 'author',
                'description' => 'Can create and edit their own content',
                'level' => 30,
                'is_active' => true,
            ]),

            'moderator' => Role::create([
                'name' => 'Moderator',
                'slug' => 'moderator',
                'description' => 'Can moderate comments and user-generated content',
                'level' => 40,
                'is_active' => true,
            ]),

            'support' => Role::create([
                'name' => 'Support Agent',
                'slug' => 'support',
                'description' => 'Can handle customer support tickets',
                'level' => 35,
                'is_active' => true,
            ]),

            'customer' => Role::create([
                'name' => 'Customer',
                'slug' => 'customer',
                'description' => 'Customer with purchase capabilities',
                'level' => 15,
                'is_active' => true,
            ]),

            'user' => Role::create([
                'name' => 'User',
                'slug' => 'user',
                'description' => 'Regular user with basic access',
                'level' => 10,
                'is_active' => true,
            ]),

            'guest' => Role::create([
                'name' => 'Guest',
                'slug' => 'guest',
                'description' => 'Limited access for non-registered users',
                'level' => 1,
                'is_active' => true,
            ]),
        ];
    }

    /**
     * Assign permissions to roles
     */
    private function assignPermissionsToRoles(array $roles, array $permissions): void
    {
        // SUPER ADMIN - ALL PERMISSIONS
        $roles['super-admin']->syncPermissions(
            Permission::pluck('slug')->toArray()
        );

        // ADMIN - ALMOST ALL PERMISSIONS (exclude critical system operations)
        $adminPermissions = Permission::whereNotIn('slug', [
            'backups.restore',
            'backups.delete',
            'settings.security',
        ])->pluck('slug')->toArray();
        $roles['admin']->syncPermissions($adminPermissions);

        // MANAGER - COMPREHENSIVE MANAGEMENT
        $roles['manager']->syncPermissions([
            // Dashboard
            'dashboard.view', 'dashboard.analytics', 'dashboard.reports',
            
            // Users (limited)
            'users.view', 'users.show', 'users.create', 'users.edit', 'users.ban', 'users.unban',
            'users.manage-roles', 'users.activity', 'users.export',
            
            // Content Management
            'posts.view', 'posts.show', 'posts.create', 'posts.edit', 'posts.delete',
            'posts.publish', 'posts.schedule', 'posts.feature', 'posts.moderate',
            'posts.view-drafts', 'posts.view-all', 'posts.export',
            
            'categories.view', 'categories.show', 'categories.create', 'categories.edit',
            'categories.delete', 'categories.reorder',
            
            'tags.view', 'tags.create', 'tags.edit', 'tags.delete', 'tags.merge',
            
            'pages.view', 'pages.create', 'pages.edit', 'pages.delete', 'pages.publish',
            
            'menus.view', 'menus.create', 'menus.edit', 'menus.reorder',
            
            // Comments
            'comments.view', 'comments.show', 'comments.edit', 'comments.delete',
            'comments.approve', 'comments.reject', 'comments.moderate', 'comments.pin',
            
            // Media
            'media.view', 'media.upload', 'media.edit', 'media.delete', 'media.organize', 'media.view-all',
            
            // E-commerce
            'products.view', 'products.show', 'products.create', 'products.edit',
            'products.manage-inventory', 'products.manage-pricing', 'products.publish',
            'products.export',
            
            'orders.view', 'orders.show', 'orders.process', 'orders.cancel', 'orders.refund',
            'orders.history', 'orders.export',
            
            'customers.view', 'customers.show', 'customers.view-orders', 'customers.export',
            
            'coupons.view', 'coupons.create', 'coupons.edit', 'coupons.activate',
            
            // Reports
            'reports.view', 'reports.sales', 'reports.users', 'reports.analytics',
            'reports.export',
            
            // Tickets
            'tickets.view', 'tickets.edit', 'tickets.assign', 'tickets.close', 'tickets.reply',
            
            // Activity
            'activity-logs.view', 'activity-logs.export',
            
            // SEO
            'seo.meta-tags', 'seo.sitemaps', 'seo.redirects', 'seo.reports',
        ]);

        // EDITOR - FULL CONTENT MANAGEMENT
        $roles['editor']->syncPermissions([
            // Dashboard
            'dashboard.view', 'dashboard.analytics',
            
            // Posts
            'posts.view', 'posts.show', 'posts.create', 'posts.edit', 'posts.delete',
            'posts.publish', 'posts.schedule', 'posts.feature', 'posts.moderate',
            'posts.view-drafts', 'posts.view-all', 'posts.export',
            
            // Categories & Tags
            'categories.view', 'categories.show', 'categories.create', 'categories.edit', 'categories.reorder',
            'tags.view', 'tags.create', 'tags.edit', 'tags.merge',
            
            // Pages
            'pages.view', 'pages.create', 'pages.edit', 'pages.publish',
            
            // Comments
            'comments.view', 'comments.show', 'comments.edit', 'comments.delete',
            'comments.approve', 'comments.reject', 'comments.moderate', 'comments.pin',
            
            // Media
            'media.view', 'media.upload', 'media.edit', 'media.organize', 'media.view-all',
            
            // SEO
            'seo.meta-tags', 'seo.sitemaps',
        ]);

        // AUTHOR - OWN CONTENT ONLY
        $roles['author']->syncPermissions([
            // Dashboard
            'dashboard.view',
            
            // Posts
            'posts.view', 'posts.show', 'posts.create', 'posts.edit-own', 'posts.delete-own',
            
            // Categories & Tags (view only)
            'categories.view', 'tags.view', 'tags.create',
            
            // Comments
            'comments.view', 'comments.create', 'comments.edit-own', 'comments.delete-own',
            
            // Media
            'media.view', 'media.upload', 'media.delete-own',
        ]);

        // MODERATOR - COMMENT & CONTENT MODERATION
        $roles['moderator']->syncPermissions([
            // Dashboard
            'dashboard.view',
            
            // Posts (view & moderate)
            'posts.view', 'posts.show', 'posts.moderate', 'posts.view-all',
            
            // Comments (full moderation)
            'comments.view', 'comments.show', 'comments.edit', 'comments.delete',
            'comments.approve', 'comments.reject', 'comments.moderate', 'comments.pin',
            
            // Media (view only)
            'media.view',
            
            // Activity
            'activity-logs.view',
        ]);

        // SUPPORT - CUSTOMER SUPPORT
        $roles['support']->syncPermissions([
            // Dashboard
            'dashboard.view',
            
            // Customers
            'customers.view', 'customers.show', 'customers.view-orders',
            
            // Orders (view & basic management)
            'orders.view', 'orders.show', 'orders.history',
            
            // Tickets (full support access)
            'tickets.view', 'tickets.view-own', 'tickets.create', 'tickets.edit',
            'tickets.assign', 'tickets.close', 'tickets.reopen', 'tickets.reply',
            
            // Products (view only)
            'products.view', 'products.show',
            
            // Notifications
            'notifications.view', 'notifications.create', 'notifications.mark-read',
        ]);

        // CUSTOMER - E-COMMERCE USER
        $roles['customer']->syncPermissions([
            // Dashboard
            'dashboard.view',
            
            // Products
            'products.view', 'products.show',
            
            // Orders (own only)
            'orders.view', 'orders.show',
            
            // Tickets
            'tickets.view-own', 'tickets.create', 'tickets.reply',
            
            // Comments
            'comments.view', 'comments.create', 'comments.edit-own', 'comments.delete-own',
            
            // Activity
            'activity-logs.view-own',
        ]);

        // USER - BASIC USER
        $roles['user']->syncPermissions([
            // Dashboard
            'dashboard.view',
            
            // Posts (view only)
            'posts.view', 'posts.show',
            
            // Categories & Tags (view only)
            'categories.view', 'tags.view',
            
            // Comments
            'comments.view', 'comments.create', 'comments.edit-own', 'comments.delete-own',
            
            // Pages
            'pages.view',
            
            // Activity
            'activity-logs.view-own',
        ]);

        // GUEST - MINIMAL ACCESS
        $roles['guest']->syncPermissions([
            'posts.view',
            'posts.show',
            'categories.view',
            'tags.view',
            'pages.view',
            'comments.view',
            'products.view',
        ]);
    }

    /**
     * Create users with different roles
     */
    private function createUsers(array $roles): array
    {
        $users = [];

        // Super Admin
        $users['super-admin'] = User::create([
            'name' => 'Super Admin',
            'email' => 'superadmin@example.com',
            'password' => Hash::make('password'),
            'email_verified_at' => now(),
        ]);
        $users['super-admin']->assignRole('super-admin');

        // Admin
        $users['admin'] = User::create([
            'name' => 'Administrator',
            'email' => 'admin@example.com',
            'password' => Hash::make('password'),
            'email_verified_at' => now(),
        ]);
        $users['admin']->assignRole('admin');

        // Manager
        $users['manager'] = User::create([
            'name' => 'Content Manager',
            'email' => 'manager@example.com',
            'password' => Hash::make('password'),
            'email_verified_at' => now(),
        ]);
        $users['manager']->assignRole('manager');

        // Editor
        $users['editor'] = User::create([
            'name' => 'Senior Editor',
            'email' => 'editor@example.com',
            'password' => Hash::make('password'),
            'email_verified_at' => now(),
        ]);
        $users['editor']->assignRole('editor');

        // Author
        $users['author'] = User::create([
            'name' => 'Blog Author',
            'email' => 'author@example.com',
            'password' => Hash::make('password'),
            'email_verified_at' => now(),
        ]);
        $users['author']->assignRole('author');

        // Moderator
        $users['moderator'] = User::create([
            'name' => 'Community Moderator',
            'email' => 'moderator@example.com',
            'password' => Hash::make('password'),
            'email_verified_at' => now(),
        ]);
        $users['moderator']->assignRole('moderator');

        // Support Agent
        $users['support'] = User::create([
            'name' => 'Support Agent',
            'email' => 'support@example.com',
            'password' => Hash::make('password'),
            'email_verified_at' => now(),
        ]);
        $users['support']->assignRole('support');

        // Customer
        $users['customer'] = User::create([
            'name' => 'Premium Customer',
            'email' => 'customer@example.com',
            'password' => Hash::make('password'),
            'email_verified_at' => now(),
        ]);
        $users['customer']->assignRole('customer');

        // Regular User
        $users['user'] = User::create([
            'name' => 'Regular User',
            'email' => 'user@example.com',
            'password' => Hash::make('password'),
            'email_verified_at' => now(),
        ]);
        $users['user']->assignRole('user');

        // Multi-Role User (Editor + Moderator)
        $users['multi-role'] = User::create([
            'name' => 'Multi Role User',
            'email' => 'multirole@example.com',
            'password' => Hash::make('password'),
            'email_verified_at' => now(),
        ]);
        $users['multi-role']->assignRole(['editor', 'moderator']);

        // User with Temporary Role (Premium for 30 days)
        $users['temp-role'] = User::create([
            'name' => 'Temporary Premium User',
            'email' => 'temprole@example.com',
            'password' => Hash::make('password'),
            'email_verified_at' => now(),
        ]);
        $users['temp-role']->assignRole('user');
        $users['temp-role']->assignRole('customer', ['expires_at' => now()->addDays(30)]);

        return $users;
    }

    /**
     * Assign direct permissions to specific users
     */
    private function assignDirectPermissions(array $users, array $permissions): void
    {
        // Give Author extra publish permission
        $users['author']->givePermissionTo('posts.publish');

        // Give Moderator some extra permissions
        $users['moderator']->givePermissionTo([
            'posts.edit',
            'media.delete',
        ]);

        // Give Support agent order management permissions
        $users['support']->givePermissionTo([
            'orders.process',
            'orders.cancel',
        ]);

        // Give Customer temporary premium features
        $users['customer']->givePermissionTo('reports.view', [
            'expires_at' => now()->addDays(30)
        ]);

        // Give Regular user temporary content creation (7 day trial)
        $users['user']->givePermissionTo([
            'posts.create',
            'posts.edit-own'
        ], [
            'expires_at' => now()->addDays(7)
        ]);

        // Forbid specific permission (even though role has it)
        $users['editor']->forbidPermission('posts.delete');

        // Multi-role user gets extra API access
        $users['multi-role']->givePermissionTo([
            'api.view-keys',
            'api.create-keys',
            'api.view-logs',
        ]);
    }

    /**
     * Display login credentials
     */
    private function displayLoginCredentials(): void
    {
        $this->command->info('');
        $this->command->info('═══════════════════════════════════════════════════════');
        $this->command->info('           LOGIN CREDENTIALS (password: password)');
        $this->command->info('═══════════════════════════════════════════════════════');
        $this->command->table(
            ['Role', 'Email', 'Description'],
            [
                ['Super Admin', 'superadmin@example.com', 'Full system access'],
                ['Administrator', 'admin@example.com', 'Nearly full access'],
                ['Manager', 'manager@example.com', 'Content & user management'],
                ['Editor', 'editor@example.com', 'Full content management'],
                ['Author', 'author@example.com', 'Create own content + publish'],
                ['Moderator', 'moderator@example.com', 'Comment moderation + extras'],
                ['Support', 'support@example.com', 'Customer support + orders'],
                ['Customer', 'customer@example.com', 'E-commerce customer'],
                ['User', 'user@example.com', 'Basic user + trial features'],
                ['Multi-Role', 'multirole@example.com', 'Editor + Moderator + API'],
                ['Temp Role', 'temprole@example.com', 'User + 30-day Customer'],
            ]
        );
        $this->command->info('═══════════════════════════════════════════════════════');
        $this->command->info('');
        
        // Display statistics
        $totalPermissions = Permission::count();
        $totalRoles = Role::count();
        $totalUsers = User::count();
        
        $this->command->info("📊 STATISTICS:");
        $this->command->info("   • Total Permissions: {$totalPermissions}");
        $this->command->info("   • Total Roles: {$totalRoles}");
        $this->command->info("   • Total Users: {$totalUsers}");
        $this->command->info('');
        $this->command->info('✨ RBAC System Setup Complete!');
    }
}
